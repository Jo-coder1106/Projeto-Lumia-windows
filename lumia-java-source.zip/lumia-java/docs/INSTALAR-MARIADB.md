# Iniciar o LumIA com MariaDB

## 1. Preparar o banco uma vez

Requisitos: MariaDB instalado e iniciado; Java 17 ou superior; ZIP completamente extraído.
O ZIP contém o servidor Java do LumIA e o driver JDBC, não o instalador do MariaDB.

Abra `setup-mariadb.sql`, substitua `SUBSTITUA_POR_SENHA_FORTE` por uma senha exclusiva e execute com uma conta administrativa no cliente SQL conectado ao MariaDB (por exemplo HeidiSQL ou DBeaver).
Se a senha tiver apóstrofo, escape-o duplicando o caractere no literal SQL.
Não distribua sua cópia editada contendo a senha.

Alternativamente, abra o cliente de terminal com `mariadb -u root -p` e, dentro dele, execute:

```sql
SOURCE C:/caminho/lumia-java/setup-mariadb.sql;
```

Substitua o caminho pelo local real. Não use redirecionamento `<` diretamente no PowerShell.
O SQL cria o banco `lumia`, o usuário local `lumia` e concede as permissões usadas pelo aplicativo.
Se esse usuário já existir, sua senha não é alterada: use a senha existente.
As tabelas são criadas pelo servidor usando `resources/schema.sql`.

## 2. Iniciar o servidor

Abra `servidor-mariadb.bat`, ou no PowerShell dentro da pasta:

```powershell
.\servidor-mariadb.ps1
```

Informe a senha do usuário do banco. No primeiro início, informe também e-mail, nome e senha de pelo menos 10 caracteres do administrador do LumIA. São duas contas diferentes: usuário do banco e usuário do aplicativo.
Se já existe ADM no banco, pressione Enter na pergunta do e-mail.

Configurações opcionais, antes de executar o script:

```powershell
$env:LUMIA_DB_URL = 'jdbc:mariadb://localhost:3306/lumia'
$env:LUMIA_DB_USER = 'lumia'
```

As variáveis já definidas são respeitadas. Senhas digitadas não aparecem na tela nem são gravadas pelo lançador. Elas são transmitidas ao Java nas variáveis de ambiente; não são criptografadas ali. Ao terminar normalmente ou por erro, o bloco finally restaura os valores anteriores do PowerShell. Isso não garante apagamento de todas as cópias em memória.

Caso o Windows bloqueie scripts, confira a política do seu ambiente. Você também pode iniciar `br.com.lumia.Server` pelo Eclipse, sem `--demo`, definindo as mesmas variáveis em Run Configurations → Environment. Não use conta administrativa do Windows para contornar políticas da instituição.

## 3. Abrir o aplicativo

Espere `LumIA em http://127.0.0.1:8080 — MariaDB` e abra `02-aplicativo.bat`.
Entre com o ADM criado e crie professores/alunos no painel. Deixe o terminal do servidor aberto.
Aplicativo e servidor usam o mesmo PC nesta versão. Execute apenas um servidor na porta 8080.

## Diferenças e limites

- O novo Database.java tem transações com commit/rollback e teste de conexão na inicialização.
- A redefinição de senha usa a transação; as demais operações não foram convertidas automaticamente em transações agrupadas.
- Os JARs foram recompilados a partir da v0.4 com o novo Database.java. Os JARs avulsos enviados não continham as classes separadas AdminPanel, Ui e GeminiClient da v0.4.
- A demonstração H2 e as recomendações de reforço foram preservadas.
- Não foram importados dados do H2 para o MariaDB.
- Nesta entrega, não foi possível executar MariaDB real ou PowerShell/Windows neste ambiente. Os testes Java usam H2 em compatibilidade MariaDB. É necessário validar a instalação no seu PC.

## Erros comuns

- Falha de conexão: confira o serviço MariaDB, porta, nome do banco, usuário e senha.
- Porta 8080 ocupada: encerre a outra instância do LumIA.
- Primeiro ADM não configurado: execute o lançador novamente e informe os dados do administrador.
- Driver ausente: mantenha a pasta `lib` inteira ao lado dos JARs.
