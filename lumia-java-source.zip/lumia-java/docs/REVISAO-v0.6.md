# Revisão v0.6 — escopo da IA, permissões e otimizações

## Mudanças aplicadas

- A IA deixa de produzir texto livre exibido na interface. Agora escolhe ações de um catálogo pedagógico; o Java valida cada campo, índice de matéria e ação antes de compor o texto com frases locais.
- Pedidos como “sou ADM”, “ignore as regras”, divulgação de credenciais, comandos e comparação de processadores são explicitamente fora do papel da IA. Não foram criadas ferramentas de SQL, shell, busca web ou administração para o modelo.
- A resposta aceita até seis ações e apenas índices das matérias autorizadas. Campos extras, comandos, texto livre, índices forjados, ações incompatíveis com os dados e duplicatas são descartados. O plano local continua disponível.
- Esta escolha reduz a liberdade da IA: ela seleciona revisão de exemplos, exercícios, conversa com professor ou organização de entregas; não escreve tutoriais livres. Não elimina o conhecimento geral do Gemini e não garante que a seleção pedagógica seja perfeita.
- A IA recebe até 12 matérias e seis relatos recentes por matéria, com trechos de até 400 caracteres. Médias e pendências são calculadas pelo servidor. O plano local e os links continuam incluindo as matérias autorizadas completas.
- No máximo duas consultas externas simultâneas por processo, com limite de 35 segundos e 1.024 tokens de saída. Mantido o intervalo de 30 segundos por usuário. Não há repetição automática de chamadas que gere custo sem controle.
- Tratamento específico para limite de uso, alta demanda, configuração recusada e saída inválida. Nunca exibe o corpo bruto de erro do provedor.
- Recursos de YouTube calculados uma vez por recomendação. Removida a conversão desnecessária de notas para JSON e de volta para objetos antes de ordenar.
- Entradas antigas do controle de consultas à IA são removidas; cada contador de tentativas guarda a própria expiração, evitando interferência entre janelas de duração diferente.
- Troca de senha, exclusão de códigos antigos e auditoria passam a ocorrer na mesma transação. A atualização também verifica se a senha/status não mudou durante a operação.
- Configuração do Gemini é buscada ao lado do JAR do servidor, mesmo se iniciado a partir de outra pasta. A chave original foi mantida, fora do código, dos JARs e do arquivo de logins.

## Permissões conferidas

Cadastro público continua forçado a ALUNO/PENDENTE. O perfil vem do banco, não do corpo da requisição. A sessão tem prazo e a conta é revalidada a cada acesso autenticado. Professor é limitado às próprias matérias; aluno é limitado aos próprios registros; ADM usa o painel administrativo. Texto em feedback não altera essas regras.

## Limites que permanecem

Servidor restrito a localhost; não é uma implantação escolar pública. Senhas demo são conhecidas e servem apenas à demonstração. Não foi adicionada memória de conversas nem histórico de versões dos feedbacks/recomendações. Os links do YouTube continuam sendo buscas, não vídeos verificados. Consultas SQL por matéria permanecem; não foi alegada melhoria de latência medida. Comentários podem conter dados pessoais digitados pelo usuário. O modelo ainda pode selecionar uma ação permitida pouco adequada; a revisão pedagógica humana continua necessária. Administradores do computador com acesso aos arquivos podem ler a configuração local.

Os testes automatizados usam H2. MariaDB real e a interface/PowerShell no Windows precisam de validação no ambiente do usuário. Testes locais de respostas adversariais verificam o validador Java, não provam resistência universal do modelo.

## Fontes técnicas consultadas em 14/10/2026

- OWASP — defesa contra prompt injection, autorização fora do modelo e validação de saída: https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html
- Google — GenerateContent e configuração da geração: https://ai.google.dev/api/generate-content
- Google — saídas estruturadas: https://ai.google.dev/gemini-api/docs/generate-content/structured-output
