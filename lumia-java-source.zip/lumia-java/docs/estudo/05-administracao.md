# Administração

**Arquivos:** AdminPanel.java e AdminService.java.

## Caminho no código

AdminPanel coleta as informações e envia pedidos /admin/*. Server bloqueia usuários sem perfil ADM. AdminService valida a operação, altera os cadastros e registra o histórico. Contas públicas ficam pendentes; o ADM aprova ou desativa.

## Conceitos

Criar uma conta pode gerar senha temporária. O usuário é obrigado a trocá-la. Redefinição usa código com validade e uso único. Desativar revoga sessões e bloqueia novos logins.

## Exercício curto

Siga Aprovar / reativar: adminStatus → adminPost → /admin/user-status → atualização no banco.

## Pergunta para apresentação

Qual é a diferença entre desativar uma conta e apagar o histórico acadêmico dela?
