# Recomendações e reforço

**Arquivos:** Recommendations.java, GeminiClient.java, AiPolicy.java e Desktop.java.

## Regra pedagógica

Nota não determina proficiência. A média é apenas um resumo dos registros. Relatos do aluno e do professor ajudam a discutir dificuldades, sem diagnóstico automático.

O sistema seleciona até três assuntos distintos com as menores notas de atividades entregues em cada matéria. Não há corte de aprovação: menor nota é uma prioridade relativa para revisão. Atividades não entregues aparecem como pendências e não entram na média do plano nem na seleção de reforço.

## YouTube

Cada assunto gera um botão de busca no YouTube com matéria e título da atividade. São buscas, não vídeos verificados ou um catálogo de recomendações individuais. Não exigem chave YouTube. Nome, e-mail, nota e feedback não entram no endereço de busca.

Use títulos descritivos, como “Equações do primeiro grau”, em vez de “Prova 1”. O sistema não consegue descobrir o conteúdo de uma questão apenas pela nota.

O próximo passo para recomendar vídeos específicos é manter um catálogo revisado pelo professor, ou consultar a API do YouTube e verificar pertinência. Esta versão não afirma ter feito essa verificação.

## IA com escopo controlado

GeminiClient envia um contexto limitado e solicita JSON. AiPolicy só aceita índices de matérias já autorizadas e quatro ações de estudo. O texto mostrado vem de frases locais, não de texto livre do modelo. Se vier comando, explicação de hardware, campos extras ou IDs externos, a resposta é descartada e continua o plano por regras.

O modelo ainda tem conhecimento geral, mas não recebe ferramentas para executar ações nem decide permissões. Mesmo uma sugestão válida pode ser pedagogicamente inadequada: confira com o professor. Médias não determinam proficiência. Links de YouTube continuam sendo criados pelo sistema.

A chave vem do arquivo privado ao lado do JAR ou de variável de ambiente. Ela não faz parte do contexto textual enviado ao modelo. Comentários são dados não confiáveis; o papel informado neles não altera o perfil da sessão.

## Exercício

Cadastre duas atividades entregues com notas 3 e 7 e uma não entregue com nota 0. Confira a ordem do reforço e a média 5 das entregues. O boletim e a visão geral continuam com suas regras próprias; esta mudança é do plano de reforço.
