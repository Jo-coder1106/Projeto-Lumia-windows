# Telas

**Arquivos:** Desktop.java, AdminPanel.java e Ui.java.

## Caminho no código

Desktop.main inicia o Swing na thread de interface. loginPanel cria os campos e o botão Entrar. O evento do botão lê os campos e usa task para executar a comunicação sem bloquear a janela. AdminPanel reúne a interface do ADM; Ui fornece componentes e aparência comuns.

## Conceitos

JFrame é a janela; JPanel organiza componentes; JButton dispara uma ação; JTextField recebe texto. SwingWorker executa a tarefa demorada fora da thread de interface e entrega o resultado na interface.

## Exercício curto

Altere um texto de botão, compile e confira a tela. Depois localize a chamada disparada por esse botão.

## Pergunta para apresentação

Por que uma consulta ao servidor não deve rodar diretamente no evento do botão?
