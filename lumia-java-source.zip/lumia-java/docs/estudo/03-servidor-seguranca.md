# Servidor e segurança

**Arquivos:** Server.java e Passwords.java.

## Caminho no código

Server.main inicia o banco e o servidor local. handle trata o pedido e os erros. route identifica o caminho e chama métodos específicos. auth confere sessão, status da conta e troca obrigatória de senha. loginOrRegister trata a entrada e o cadastro.

## Conceitos

Autenticação verifica quem entrou; autorização verifica o que essa conta pode fazer. Passwords usa PBKDF2 com sal aleatório. O hash não é uma senha criptografada para recuperar depois. As sessões expiram e ficam em memória.

## Exercício curto

Acompanhe /login até sessions.put. Depois acompanhe uma chamada /grades passando por auth e pelas verificações de professor/matrícula.

## Pergunta para apresentação

Por que esconder um botão na tela não basta para impedir uma ação proibida?
