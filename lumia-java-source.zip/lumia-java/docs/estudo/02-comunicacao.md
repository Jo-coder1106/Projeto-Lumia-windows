# Comunicação

**Arquivos:** ApiClient.java e Json.java.

## Caminho no código

ApiClient.post envia um objeto convertido em JSON. ApiClient.get consulta uma rota. O token da sessão segue no cabeçalho Authorization. O servidor responde com JSON e um código HTTP; ApiException informa quando a operação falhou.

## Conceitos

GET consulta; POST envia uma operação. JSON transporta dados. O endereço do servidor é diferente do endereço da API do Gemini. O aplicativo não conhece a senha do banco.

## Exercício curto

Siga o botão Entrar até api.post("/login", ...). Identifique os campos enviados e os campos retornados.

## Pergunta para apresentação

Qual é a diferença entre o corpo do pedido e o cabeçalho de autorização?
