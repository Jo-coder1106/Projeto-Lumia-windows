# Banco de dados

**Arquivos:** Database.java e resources/schema.sql.

## Caminho no código

query devolve linhas; update altera dados; insert cadastra e devolve o ID. bind preenche os parâmetros do PreparedStatement. initialize cria tabelas e verifica a migração. redeemReset consome o código e troca a senha na mesma transação.

## Conceitos

PK identifica; FK relaciona. PreparedStatement separa a consulta SQL dos valores recebidos. Uma transação permite confirmar tudo ou desfazer em caso de falha. try-with-resources fecha recursos JDBC.

## Exercício curto

Localize users, courses e enrollments no SQL. Explique por que a chave de enrollments tem duas colunas.

## Pergunta para apresentação

O que ocorreria se o código de redefinição fosse apagado, mas a atualização da senha falhasse fora de uma transação?
