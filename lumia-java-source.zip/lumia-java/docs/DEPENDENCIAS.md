# Bibliotecas incluídas

Os JARs originais não foram modificados. Podem ser substituídos por versões compatíveis na pasta `lib`.

| Biblioteca | Versão | Uso | Licença |
|---|---|---|---|
| Gson | 2.11.0 | JSON | Apache 2.0 |
| MariaDB Connector/J | 3.5.3 | Conexão JDBC | LGPL 2.1 ou posterior |
| H2 | 2.3.232 | Demonstração local | MPL 2.0 ou EPL 1.0 |

Os avisos incluídos pelos distribuidores estão nos próprios JARs. Os arquivos-fonte correspondentes às versões distribuídas estão em `docs/fontes-dependencias`.

Origens oficiais dos projetos:
- https://github.com/google/gson
- https://github.com/mariadb-corporation/mariadb-connector-j
- https://github.com/h2database/h2database

Artefatos e fontes obtidos do Maven Central nas coordenadas `com.google.code.gson:gson:2.11.0`, `org.mariadb.jdbc:mariadb-java-client:3.5.3` e `com.h2database:h2:2.3.232`.
