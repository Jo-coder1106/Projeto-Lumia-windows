# Validação da revisão v0.6 — 14/10/2026

- Compilação Java 17 e ambos os JARs.
- 55 requisições acadêmicas + 59 administrativas + 29 adversariais de autorização: 143 requisições.
- 31 verificações da política/saída da IA: JSON válido, rejeição de texto livre, comandos, campos extras, índices indevidos, duplicatas e ações incompatíveis com os dados; minimização de contexto e ausência de ferramentas.
- Testes DatabaseIntegration: commit/rollback, reset de uso único e persistência H2.
- Os testes offline desabilitam chamadas externas explicitamente, sem remover a chave do projeto.
- Teste real com dados fictícios e prompt adversarial: HTTP 503; não foi obtida geração válida do provedor. Veja TESTE-IA-REAL.txt.
- Nenhum percentual de desempenho medido. Nenhuma garantia de invulnerabilidade ou de qualidade pedagógica universal.
- MariaDB real, interface gráfica e PowerShell/Windows ainda requerem validação no PC do usuário.

Para repetir: com JDK 17+ e Python 3, execute `python test/run-tests.py`. Porta 8080 livre. A suíte usa bancos temporários.
