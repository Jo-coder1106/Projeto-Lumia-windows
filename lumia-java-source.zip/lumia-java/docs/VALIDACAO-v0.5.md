# Validação da integração v0.5 — 14/10/2026

- Compilação e geração dos dois JARs: aprovadas.
- 55 requisições acadêmicas e 59 administrativas (114 no total): aprovadas em H2.
- DatabaseIntegration.java: commit, rollback SQL e de aplicação, preservação do token em falha, token de uso único e persistência após reinicialização: aprovados em H2.
- Inicialização com endereço MariaDB inacessível: saída de erro com orientação, sem exibir a senha: aprovada.
- Classes de transação e Gemini incluídas no servidor; AdminPanel e Ui incluídas no aplicativo.
- MariaDB real, scripts PowerShell e interface gráfica no Windows: não executados neste ambiente.
- Chamada externa ao Gemini: não executada.

Para repetir os testes locais: instale JDK 17+ e Python 3 e execute `python test/run-tests.py` dentro da pasta do projeto. A porta 8080 deve estar livre. São usados bancos temporários.
