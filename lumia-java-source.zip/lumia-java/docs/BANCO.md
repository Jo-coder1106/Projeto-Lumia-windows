# Banco — PK, FK e relações

**PK** identifica um registro. **FK** aponta para um registro de outra tabela.

| Tabela | PK | FK | Guarda |
|---|---|---|---|
| users | id | — | Nome, e-mail, hash da senha, perfil, status e troca obrigatória |
| courses | id | teacher_id → users.id | Matéria/turma de um professor |
| enrollments | course_id + student_id | courses.id e users.id | Matrícula do aluno |
| lessons | id | course_id → courses.id | Aula/atividade |
| grades | lesson_id + student_id | lessons.id e users.id | Nota e entrega |
| feedback | id | lesson_id → lessons.id; author_id e student_id → users.id | Relato sobre a aula e o aluno |

```mermaid
erDiagram
    USERS ||--o{ COURSES : leciona
    USERS ||--o{ ENROLLMENTS : matricula
    COURSES ||--o{ ENROLLMENTS : possui
    COURSES ||--o{ LESSONS : possui
    LESSONS ||--o{ GRADES : recebe
    USERS ||--o{ GRADES : aluno
    LESSONS ||--o{ FEEDBACK : contextualiza
    USERS ||--o{ FEEDBACK : autor
    USERS ||--o{ FEEDBACK : aluno_envolvido
```

**Por que feedback tem autor e aluno?** Se o aluno escreve, os dois IDs são dele. Se o professor escreve, o autor é o professor e `student_id` identifica o aluno acompanhado. O professor da aula é conhecido pela matéria.

A combinação `(lesson_id, author_id, student_id)` é única: um novo envio atualiza o mesmo relato. Este MVP não mantém versões anteriores do feedback.

FKs garantem a existência dos registros; o servidor também verifica perfil e matrícula. Uma FK para `users` sozinha não garante que o usuário seja aluno ou professor.

Esquema executável: `resources/schema.sql`. Nomes de tabelas estão em inglês; interface e explicações estão em português.


Na v0.2, `users.role` aceita `ADM`, `ALUNO` e `PROFESSOR`. `status` aceita `PENDENTE`, `ATIVO` e `INATIVO`. Contas da v0.1 permanecem ativas após migração.

| Nova tabela | PK | FK | Guarda |
|---|---|---|---|
| password_resets | user_id | users.id | Hash do código e validade; nunca o código em texto puro |
| audit_log | id | actor_id → users.id | Quem executou a operação, tipo, registro afetado e data |

`audit_log.target_id` pode apontar a uma conta ou matéria, conforme a ação; por isso não é uma FK para uma única tabela.
