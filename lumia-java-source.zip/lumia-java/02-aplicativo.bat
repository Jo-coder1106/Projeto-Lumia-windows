@echo off
cd /d "%~dp0"
java -jar lumia-desktop.jar
pause
