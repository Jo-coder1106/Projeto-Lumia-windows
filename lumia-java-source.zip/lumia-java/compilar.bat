@echo off
cd /d "%~dp0"
if exist build rmdir /s /q build
mkdir build
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 --release 17 -cp lib\gson-2.11.0.jar -d build src\br\com\lumia\*.java
if errorlevel 1 goto erro
if not exist build\client\br\com\lumia mkdir build\client\br\com\lumia
if not exist build\server\br\com\lumia mkdir build\server\br\com\lumia
for %%n in (Desktop AdminPanel Ui ApiClient Json) do copy /y build\br\com\lumia\%%n*.class build\client\br\com\lumia\ >nul
for %%n in (Server Database Passwords Recommendations GeminiClient AiPolicy AdminService Json) do copy /y build\br\com\lumia\%%n*.class build\server\br\com\lumia\ >nul
copy /y resources\logo.jpeg build\client\ >nul
copy /y resources\schema.sql build\server\ >nul
java -m jdk.jartool/sun.tools.jar.Main --create --file lumia-desktop.jar --manifest desktop-manifest.mf -C build/client .
if errorlevel 1 goto erro
java -m jdk.jartool/sun.tools.jar.Main --create --file lumia-servidor.jar --manifest server-manifest.mf -C build/server .
if errorlevel 1 goto erro
echo Compilacao concluida.
pause
exit /b 0
:erro
echo Nao foi possivel compilar. Confira se um JDK 17 ou superior esta instalado.
pause
exit /b 1
