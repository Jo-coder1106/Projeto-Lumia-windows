# LumIA — Java para PC • v0.6 • revisão de IA e permissões

Aplicativo Swing + servidor Java. Inspirado nos três HTMLs e na identidade visual enviados.

## Testar no Windows

1. Tenha **Java 17 ou superior** instalado. Para programar no Eclipse, use um **JDK**.
2. Extraia todo o ZIP. Mantenha a pasta `lib` ao lado dos arquivos `.jar`.
3. Abra `01-servidor-demo.bat` e aguarde a mensagem de inicialização.
4. Abra `02-aplicativo.bat`.

| Perfil de demonstração | E-mail | Senha fictícia |
|---|---|---|
| ADM/TI | admin@lumia.local | Admin12345! |
| Professor | professor@lumia.local | Professor123! |
| Aluno | aluno@lumia.local | Aluno12345! |

Código da matéria fictícia: `LUMIA-DEMO`. O modo demo salva seus testes na pasta `demo-data`, usando H2. Não utiliza o MariaDB e não deve receber dados reais. Feche o servidor com Ctrl+C. Use apenas uma instância dele por vez.

## Revisão v0.6

Leia `LOGINS_E_ACESSOS.txt` para logins e permissões e `docs/REVISAO-v0.6.md` para as mudanças. A chave original está preservada em `gemini-local.properties`. A IA agora seleciona apenas ações pedagógicas que são validadas pelo Java; não há resposta livre nem administração via IA.

## O que já funciona

- Login, cadastro de aluno e logout; aprovação pelo ADM/TI e criação de professores e administradores pelo painel.
- Criação de matérias/turmas, matrícula por código e registro de aulas/atividades.
- Notas de 0 a 10, com edição por novo envio e indicação de entrega.
- Feedback por aula, de aluno e professor, incluindo clareza, atividade, dificuldade e comentário.
- Consulta dos dois relatos; aluno vê os próprios registros e professor vê suas matérias.
- Resumo da turma por matéria, médias calculadas em Java/SQL e recomendações por regras.
- Chamada opcional ao Gemini pelo servidor; se indisponível, continua com as regras.

## Mudanças, direto ao ponto

| Antes | Agora |
|---|---|
| HTML desenha a página | Swing cria janelas e campos |
| JavaScript executa o botão | Métodos Java tratam as ações |
| Nome e notas digitados em texto livre | Cadastros, matérias, aulas e notas estruturados |
| IA calcula as médias | O sistema calcula; a IA recebe os resultados |
| Chave no HTML | Chave em variável de ambiente do servidor |
| Sem banco nos arquivos recebidos | Banco guarda usuários, notas e feedbacks |
| Sem autenticação | Sessão com prazo e validação de acesso no servidor |

As páginas institucionais continuam podendo existir como site. Este ZIP não altera os HTMLs originais. O programa Java concentra o acompanhamento acadêmico; não é um navegador empacotado.

## Abrir no Eclipse

`File → Import → General → Existing Projects into Workspace` e selecione a pasta `lumia-java`.

- JDK: 17 ou superior. Codificação: UTF-8.
- `Server.java`: execute primeiro. Em **Run Configurations → Arguments**, coloque `--demo`.
- `Desktop.java`: execute depois, como Java Application.
- Após editar, `compilar.bat` recompila os dois JARs. Não requer Maven.

Comece por `COMECE-AQUI.md`. Os seis guias em `docs/estudo` explicam cada parte separadamente.

## Usar MariaDB

Leia `docs/INSTALAR-MARIADB.md`. O projeto inclui o driver, `setup-mariadb.sql`,
`servidor-mariadb.ps1` e os dois JARs recompilados juntos.

1. Com o MariaDB instalado e iniciado, prepare o banco e o usuário pelo SQL incluído.
2. Abra `servidor-mariadb.bat`: ele chama o PowerShell e pede as credenciais.
3. No primeiro início, informe o e-mail e a senha do ADM. Nas próximas vezes, deixe o e-mail em branco.
4. Aguarde a mensagem `LumIA em http://127.0.0.1:8080 — MariaDB`.
5. Abra `02-aplicativo.bat` e entre com o ADM criado.

O servidor cria as tabelas automaticamente e mantém as migrações existentes.
Faça backup antes de atualizar um banco com dados. O modo demo continua separado em H2.
As contas de demonstração não são criadas no MariaDB.

## Gemini configurado localmente

A chave e o modelo do HTML original foram colocados em `gemini-local.properties`, ao lado do JAR do servidor. Não é necessário redigitar a chave. Inicie o servidor pelos lançadores na pasta do projeto; no aplicativo, abra Recomendações → Consultar IA.

O arquivo é lido apenas pelo servidor, não está dentro dos JARs e está excluído do Git. Este ZIP contém a configuração privada solicitada: para distribuir somente as telas, use o aplicativo sem esse arquivo.

As variáveis `GEMINI_API_KEY` e `GEMINI_MODEL`, quando preenchidas, têm prioridade sobre o arquivo. Mantive o modelo indicado no HTML original. A validade da chave, a disponibilidade desse modelo e a chamada externa não foram testadas. Caso o provedor recuse a chamada, o sistema mantém as recomendações locais.

## Limites desta versão

- É uma base didática funcional, ainda não uma implantação escolar pronta.
- Testada com H2 em modo de compatibilidade MariaDB. Driver e SQL para MariaDB incluídos, mas a conexão com uma instalação real de MariaDB ainda precisa ser testada.
- A chamada real com o novo formato retornou HTTP 503 (alta demanda) em 14/10. Os testes de validação da saída são locais. Veja `docs/TESTE-IA-REAL.txt`.
- O servidor aceita conexões somente em `127.0.0.1`. Aplicativo e servidor rodam no mesmo PC nesta entrega. Para vários PCs, será necessário implantar o servidor com HTTPS, controle operacional, backups e limites de uso adequados.
- Sessões ficam em memória e expiram em 2 horas; reiniciar o servidor encerra as sessões. Senhas usam PBKDF2-HMAC-SHA256 com sal aleatório e 600 mil iterações.
- Feedbacks são identificados e visíveis às duas partes envolvidas. Não há promessa de anonimato.
- Cada “matéria / turma” pertence a um professor. Ainda não há cadastro separado de turma, bimestre, pesos, frequência ou integração com plataforma de atividades.
- Média simples das notas registradas. Ausência de nota não vira zero. Entrega e nota são campos distintos: marcar “não entregue” não zera a nota automaticamente.
- A análise geral cobre a matéria selecionada. O plano do aluno cruza as matérias em que está matriculado; o professor só analisa as suas próprias matérias.
- Ainda não há recuperação automática por e-mail, chat ou instalador `.exe`. A redefinição de senha usa código gerado pelo ADM/TI; há migração da tabela de usuários da v0.1 para v0.2.
- Notas não identificam talentos ou diagnósticos. Recomendações são apoio para decisão humana.

## Verificações realizadas

Compilação Java 17; 59 requisições de administração e 55 acadêmicas com banco demo temporário; migração v0.1 → v0.2 e reinício verificados; cadastro, duplicidade, login, tentativa de elevar perfil, isolamento entre alunos, validação e atualização de notas, feedbacks bidirecionais, médias, falta de dados, fallback sem IA, limite de chamadas e logout. Login e painel administrativo renderizados para inspeção visual em `docs/tela-login.png`; interação completa das janelas no Windows ainda precisa ser conferida no seu PC.

Testes em `test/integration.py` devem rodar só em uma demonstração descartável: criam registros fictícios. Dependem de Python 3 e de um servidor demo iniciado em banco limpo.


## Administração / TI

Entre com `admin@lumia.local` / `Admin12345!` **somente na demonstração**. Em MariaDB, use a conta definida na configuração inicial.

- **Contas:** criar aluno/professor/ADM, editar nome/e-mail, aprovar pendentes, desativar e reativar.
- **Senhas:** contas criadas pelo painel recebem senha temporária e devem trocá-la no primeiro acesso. O titular informa a senha atual e a nova senha; o ADM não vê senhas existentes.
- **Redefinição:** selecione uma conta ativa e gere o código. Entregue-o em canal privado; o usuário abre “Redefinir senha com código” no login. Expira em 10 minutos e funciona uma vez. Gerar outro invalida o anterior. Não há envio automático de e-mail.
- **Matérias/turmas:** criar, renomear e atribuir professor ativo.
- **Matrículas:** adicionar ou remover alunos. Remover matrícula não apaga notas/feedbacks históricos; o aluno perde acesso à matéria até se matricular novamente.
- **Histórico:** últimas 100 operações administrativas, sem senhas e sem códigos.

Novos cadastros públicos ficam pendentes até aprovação. Desativar conta bloqueia login e revoga sessões. Não é permitido desativar a própria conta. Os perfis de contas existentes não são trocados pelo painel para evitar transformar registros acadêmicos em outro tipo de usuário.

O ADM administra cadastros; o painel não exibe os feedbacks privados nem as senhas/chaves. “Turma” continua agrupada com matéria nesta versão, sem cadastro de turma independente. O histórico é um registro operacional básico, não uma trilha de auditoria imutável.

## Reforço por assunto (v0.4)

Notas não classificam proficiência. As menores notas de atividades entregues geram buscas no YouTube por matéria e assunto, com botões na tela de recomendações. São buscas, não vídeos verificados. Veja `docs/estudo/06-recomendacoes.md`.
