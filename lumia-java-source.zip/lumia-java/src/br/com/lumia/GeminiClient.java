package br.com.lumia;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Semaphore;

/** Apenas escolhe ações pedagógicas. Não recebe ferramentas ou acesso administrativo. */
public final class GeminiClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();
    private static final Semaphore CALLS = new Semaphore(2);
    private GeminiClient() {}

    private static Map<String, Object> fallback(String plan, String reason) {
        return Json.map("source", "REGRAS", "aiStatus", reason, "text", plan + "\n\n" + reason);
    }

    static Properties configuration() {
        Properties local = new Properties();
        var file = java.nio.file.Path.of("gemini-local.properties");
        try {
            var location = java.nio.file.Path.of(GeminiClient.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            if (java.nio.file.Files.isRegularFile(location)) file = location.resolveSibling("gemini-local.properties");
            if (java.nio.file.Files.isRegularFile(file)) {
                try (var reader = java.nio.file.Files.newBufferedReader(file)) { local.load(reader); }
            }
        } catch (Exception ignored) { /* Variáveis de ambiente continuam disponíveis. */ }
        for (String name : List.of("GEMINI_API_KEY", "GEMINI_MODEL")) {
            String value = System.getenv(name);
            if (value != null && !value.isBlank()) local.setProperty(name, value);
        }
        return local;
    }

    static String payload(List<Map<String, Object>> evidence) {
        return Json.GSON.toJson(Json.map(
                "systemInstruction", Json.map("parts", List.of(Json.map("text", AiPolicy.INSTRUCTION))),
                "contents", List.of(Json.map("role", "user", "parts", List.of(
                        Json.map("text", Json.GSON.toJson(AiPolicy.context(evidence)))))),
                "generationConfig", Json.map("responseMimeType", "application/json",
                        "responseJsonSchema", AiPolicy.schema(), "maxOutputTokens", 1024)));
    }

    public static Map<String, Object> enhance(List<Map<String, Object>> evidence, String plan) {
        var config = configuration();
        String key = config.getProperty("GEMINI_API_KEY"), model = config.getProperty("GEMINI_MODEL");
        if (key == null || key.isBlank() || model == null || !model.matches("[a-zA-Z0-9._-]+"))
            return fallback(plan, "IA não configurada no servidor. Exibindo recomendações por regras.");
        if (evidence.isEmpty() || evidence.stream().allMatch(c -> AiPolicy.allowed(c).isEmpty()))
            return fallback(plan, "Sem dados suficientes para selecionar ações com IA.");
        String payload = payload(evidence);
        if (payload.length() > 48000) return fallback(plan, "Contexto extenso: exibindo o plano local completo.");
        if (!CALLS.tryAcquire()) return fallback(plan, "IA ocupada com outras consultas. Tente novamente depois.");
        try {
            var request = HttpRequest.newBuilder(URI.create(
                            "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent"))
                    .header("Content-Type", "application/json").header("x-goog-api-key", key)
                    .timeout(Duration.ofSeconds(35)).POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            var response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                String reason = switch (response.statusCode()) {
                    case 429 -> "Limite de consultas do provedor atingido.";
                    case 503 -> "Modelo com alta demanda. Tente novamente depois.";
                    case 400, 401, 403, 404 -> "O provedor recusou a configuração ou o pedido. Confira chave, modelo e permissões.";
                    default -> "Provedor temporariamente indisponível.";
                };
                return fallback(plan, reason + " Exibindo recomendações locais.");
            }
            if (response.body().length() > 65536) return fallback(plan, "Resposta da IA excedeu o limite permitido.");
            var root = JsonParser.parseString(response.body()).getAsJsonObject();
            var candidate = root.getAsJsonArray("candidates").get(0).getAsJsonObject();
            if (!candidate.has("finishReason") || !"STOP".equals(candidate.get("finishReason").getAsString()))
                return fallback(plan, "Resposta da IA incompleta ou bloqueada. Exibindo regras locais.");
            StringBuilder answer = new StringBuilder();
            for (var value : candidate.getAsJsonObject("content").getAsJsonArray("parts")) {
                var part = value.getAsJsonObject();
                if (part.has("text") && (!part.has("thought") || !part.get("thought").getAsBoolean()))
                    answer.append(part.get("text").getAsString());
            }
            String safeText;
            try { safeText = AiPolicy.render(answer.toString(), evidence); }
            catch (RuntimeException invalid) {
                return fallback(plan, "Resposta da IA fora do formato permitido; descartada. Exibindo regras locais.");
            }
            if (safeText.isBlank()) return fallback(plan, "A IA não selecionou ações adicionais no escopo permitido.");
            return Json.map("source", "GEMINI", "aiStatus", "Ações validadas pelo servidor",
                    "text", "AÇÕES PEDAGÓGICAS — seleção da IA\n" + safeText
                            + "\nAté 12 matérias e 6 relatos por matéria no contexto da IA. Confira as sugestões com o professor.\n\n" + plan);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return fallback(plan, "Consulta interrompida. Exibindo recomendações locais.");
        } catch (Exception e) {
            return fallback(plan, "Não foi possível consultar a IA. Exibindo recomendações locais.");
        } finally { CALLS.release(); }
    }
}
