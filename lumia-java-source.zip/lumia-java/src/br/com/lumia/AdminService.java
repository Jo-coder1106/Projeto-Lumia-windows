package br.com.lumia;

import com.google.gson.JsonObject;

import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.function.LongConsumer;

/** Administração autorizada pelo servidor. Não retorna hashes de senha ou chaves. */
public final class AdminService {
    private final Database db;
    private final LongConsumer revoke;

    public AdminService(Database db, LongConsumer revoke) {
        this.db = db;
        this.revoke = revoke;
    }

    public static boolean flag(Object value) {
        return Boolean.TRUE.equals(value)
                || "1".equals(String.valueOf(value))
                || "true".equalsIgnoreCase(String.valueOf(value));
    }

    public static String digest(String value) throws Exception {
        return HexFormat.of()
                .formatHex(
                        MessageDigest.getInstance("SHA-256")
                                .digest(value.getBytes(StandardCharsets.UTF_8)));
    }

    private static String random() {
        byte[] bytes = new byte[24];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public static String email(JsonObject b) {
        String email = Json.required(b, "email", 190).toLowerCase(Locale.ROOT);
        if (!email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))
            throw new IllegalArgumentException("E-mail inválido.");
        return email;
    }

    private Map<String, Object> user(long id) throws Exception {
        var rows = db.query("SELECT id,name,email,role,status FROM users WHERE id=?", id);
        if (rows.isEmpty()) throw new IllegalArgumentException("Conta não encontrada.");
        return rows.get(0);
    }

    private void checkRole(long id, String role) throws Exception {
        var u = user(id);
        if (!role.equals(u.get("role")) || !"ATIVO".equals(u.get("status")))
            throw new IllegalArgumentException(
                    "Selecione uma conta ativa com perfil " + role + ".");
    }

    private void audit(long actor, String action, long target) throws Exception {
        db.insert(
                "INSERT INTO audit_log(actor_id,action,target_id) VALUES(?,?,?)",
                actor,
                action,
                target);
    }

    /**
     * Serializa alterações administrativas para proteger o último ADM contra operações
     * concorrentes.
     */
    public synchronized Object handle(long actor, String path, String method, JsonObject b)
            throws Exception {
        if (!"ADM".equals(user(actor).get("role")) || !"ATIVO".equals(user(actor).get("status")))
            throw new SecurityException("Acesso exclusivo do ADM/TI.");
        if (method.equals("GET"))
            return switch (path) {
                case "/admin/users" ->
                        db.query(
                                "SELECT id,name,email,role,status,must_change_password FROM users"
                                    + " ORDER BY name");
                case "/admin/courses" ->
                        db.query(
                                "SELECT c.id,c.name,c.teacher_id,u.name AS teacher,c.join_code FROM"
                                    + " courses c JOIN users u ON u.id=c.teacher_id ORDER BY"
                                    + " c.name");
                case "/admin/enrollments" ->
                        db.query(
                                "SELECT e.course_id,c.name AS course,e.student_id,u.name AS student"
                                    + " FROM enrollments e JOIN courses c ON c.id=e.course_id JOIN"
                                    + " users u ON u.id=e.student_id ORDER BY c.name,u.name");
                case "/admin/audit" ->
                        db.query(
                                "SELECT a.id,u.name AS actor,a.action,a.target_id,a.created_at FROM"
                                    + " audit_log a JOIN users u ON u.id=a.actor_id ORDER BY a.id"
                                    + " DESC LIMIT 100");
                default ->
                        throw new IllegalArgumentException(
                                "Operação administrativa não encontrada.");
            };
        if (!method.equals("POST")) throw new IllegalArgumentException("Método não permitido.");
        switch (path) {
            case "/admin/users" -> {
                String name = Json.required(b, "name", 120),
                        email = email(b),
                        role = Json.required(b, "role", 12);
                if (!Set.of("ALUNO", "PROFESSOR", "ADM").contains(role))
                    throw new IllegalArgumentException("Perfil inválido.");
                String temporary = random();
                long id =
                        db.insert(
                                "INSERT INTO"
                                    + " users(name,email,password_hash,role,status,must_change_password)"
                                    + " VALUES(?,?,?,?,'ATIVO',TRUE)",
                                name,
                                email,
                                Passwords.hash(temporary),
                                role);
                audit(actor, "CRIAR_CONTA_" + role, id);
                return Json.map(
                        "message",
                        "Conta criada. Entregue a senha temporária por um canal privado; a troca"
                            + " será obrigatória.",
                        "temporaryPassword",
                        temporary,
                        "id",
                        id);
            }
            case "/admin/user-edit" -> {
                long id = Json.id(b, "id");
                user(id);
                db.update(
                        "UPDATE users SET name=?,email=? WHERE id=?",
                        Json.required(b, "name", 120),
                        email(b),
                        id);
                audit(actor, "EDITAR_CONTA", id);
                revoke.accept(id);
            }
            case "/admin/user-status" -> {
                long id = Json.id(b, "id");
                var target = user(id);
                String status = Json.required(b, "status", 12);
                if (!Set.of("ATIVO", "INATIVO").contains(status))
                    throw new IllegalArgumentException("Status inválido.");
                if (status.equals("INATIVO")) {
                    if (id == actor)
                        throw new IllegalArgumentException(
                                "Você não pode desativar a própria conta.");
                    if (target.get("role").equals("ADM")
                            && db.query("SELECT id FROM users WHERE role='ADM' AND status='ATIVO'")
                                            .size()
                                    <= 1)
                        throw new IllegalArgumentException(
                                "Mantenha pelo menos um administrador ativo.");
                }
                db.update("UPDATE users SET status=? WHERE id=?", status, id);
                db.update("DELETE FROM password_resets WHERE user_id=?", id);
                audit(
                        actor,
                        status.equals("ATIVO") ? "APROVAR_OU_REATIVAR" : "DESATIVAR_CONTA",
                        id);
                revoke.accept(id);
            }
            case "/admin/password-reset" -> {
                long id = Json.id(b, "id");
                var target = user(id);
                if (!target.get("status").equals("ATIVO"))
                    throw new IllegalArgumentException("Ative a conta antes de gerar o código.");
                String token = random();
                long expiry = System.currentTimeMillis() + 600_000;
                db.update(
                        "INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES(?,?,?)"
                            + " ON DUPLICATE KEY UPDATE"
                            + " token_hash=VALUES(token_hash),expires_at=VALUES(expires_at)",
                        id,
                        digest(token),
                        expiry);
                audit(actor, "GERAR_CODIGO_REDEFINICAO", id);
                revoke.accept(id);
                return Json.map(
                        "message",
                        "Código válido por 10 minutos, de uso único. Entregue ao titular por canal"
                            + " privado.",
                        "resetCode",
                        token);
            }
            case "/admin/courses" -> {
                long teacher = Json.id(b, "teacherId");
                checkRole(teacher, "PROFESSOR");
                String name = Json.required(b, "name", 120);
                long id =
                        db.insert(
                                "INSERT INTO courses(name,teacher_id,join_code) VALUES(?,?,?)",
                                name,
                                teacher,
                                UUID.randomUUID()
                                        .toString()
                                        .replace("-", "")
                                        .substring(0, 12)
                                        .toUpperCase(Locale.ROOT));
                audit(actor, "CRIAR_MATERIA_TURMA", id);
            }
            case "/admin/course-edit" -> {
                long id = Json.id(b, "id"), teacher = Json.id(b, "teacherId");
                checkRole(teacher, "PROFESSOR");
                if (db.query("SELECT id FROM courses WHERE id=?", id).isEmpty())
                    throw new IllegalArgumentException("Matéria não encontrada.");
                db.update(
                        "UPDATE courses SET name=?,teacher_id=? WHERE id=?",
                        Json.required(b, "name", 120),
                        teacher,
                        id);
                audit(actor, "EDITAR_MATERIA_TURMA", id);
            }
            case "/admin/enrollment-add" -> {
                long course = Json.id(b, "courseId"), student = Json.id(b, "studentId");
                checkRole(student, "ALUNO");
                if (db.query("SELECT id FROM courses WHERE id=?", course).isEmpty())
                    throw new IllegalArgumentException("Matéria não encontrada.");
                db.update(
                        "INSERT INTO enrollments(course_id,student_id) VALUES(?,?)",
                        course,
                        student);
                audit(actor, "MATRICULAR_ALUNO_NA_TURMA_" + course, student);
            }
            case "/admin/enrollment-remove" -> {
                long course = Json.id(b, "courseId"), student = Json.id(b, "studentId");
                db.update(
                        "DELETE FROM enrollments WHERE course_id=? AND student_id=?",
                        course,
                        student);
                audit(actor, "REMOVER_MATRICULA_DA_TURMA_" + course, student);
            }
            default ->
                    throw new IllegalArgumentException("Operação administrativa não encontrada.");
        }
        return Json.map("message", "Alteração concluída.");
    }
}
