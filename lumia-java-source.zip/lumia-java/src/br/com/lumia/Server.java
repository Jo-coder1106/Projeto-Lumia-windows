package br.com.lumia;

import com.google.gson.*;
import com.sun.net.httpserver.*;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/** Servidor didático local. Uma implantação remota exige HTTPS e operação própria. */
public final class Server {
    private final Database db;
    private final AdminService admin;
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final Map<String, Attempt> attempts = new ConcurrentHashMap<>();
    private final Map<Long, Long> aiCalls = new ConcurrentHashMap<>();
    private final String dummyHash = Passwords.hash("unused-random-" + UUID.randomUUID());

    private record Session(long id, String name, String role, long until) {}

    private record Attempt(int count, long until) {}

    private static final class HttpError extends RuntimeException {
        final int status;

        HttpError(int s, String m) {
            super(m);
            status = s;
        }
    }

    public Server(Database db) {
        this.db = db;
        this.admin = new AdminService(db, this::revokeSessions);
    }

    private void revokeSessions(long id) {
        sessions.entrySet().removeIf(e -> e.getValue().id == id);
    }

    private static String env(String name, String fallback) {
        return System.getenv().getOrDefault(name, fallback);
    }

    public static void main(String[] args) throws Exception {
        boolean demo = Arrays.asList(args).contains("--demo");
        Database db =
                demo
                        ? new Database(
                                "jdbc:h2:./demo-data/lumia;MODE=MariaDB;DATABASE_TO_LOWER=TRUE",
                                "sa",
                                "")
                        : new Database(
                                env("LUMIA_DB_URL", "jdbc:mariadb://localhost:3306/lumia"),
                                env("LUMIA_DB_USER", "lumia"),
                                env("LUMIA_DB_PASSWORD", ""));
        try {
            db.ping();
        } catch (java.sql.SQLException e) {
            System.err.println("Não foi possível conectar ao banco. Confira se o serviço está ativo, "
                    + "se o banco lumia existe e se LUMIA_DB_URL, LUMIA_DB_USER e a senha estão corretos. "
                    + "SQLState: " + e.getSQLState());
            System.exit(1);
            return;
        }
        db.initialize();
        Server server = new Server(db);
        if (demo) {
            server.createUserIfMissing(
                    "Professor Demo", "professor@lumia.local", "Professor123!", "PROFESSOR");
            server.createUserIfMissing("Aluno Demo", "aluno@lumia.local", "Aluno12345!", "ALUNO");
            server.createUserIfMissing(
                    "Administrador Demo", "admin@lumia.local", "Admin12345!", "ADM");
            server.seedDemo();
        } else {
            if (db.query("SELECT id FROM users WHERE role='ADM'").isEmpty()) {
                String adminEmail = env("LUMIA_ADMIN_EMAIL", "").trim().toLowerCase(Locale.ROOT);
                String adminPassword = env("LUMIA_ADMIN_PASSWORD", "");
                if (adminEmail.isBlank())
                    throw new IllegalStateException(
                            "Configure LUMIA_ADMIN_EMAIL e LUMIA_ADMIN_PASSWORD para criar o"
                                + " primeiro ADM/TI.");
                validateEmail(adminEmail);
                validatePassword(adminPassword);
                if (!db.query("SELECT id FROM users WHERE email=?", adminEmail).isEmpty())
                    throw new IllegalStateException(
                            "O e-mail inicial do ADM já pertence a outra conta. Use outro e-mail.");
                server.createUserIfMissing(
                        env("LUMIA_ADMIN_NAME", "Administrador"), adminEmail, adminPassword, "ADM");
            }
            String email = env("LUMIA_TEACHER_EMAIL", ""),
                    password = env("LUMIA_TEACHER_PASSWORD", "");
            if (!email.isBlank()) {
                validateEmail(email);
                validatePassword(password);
                server.createUserIfMissing(
                        env("LUMIA_TEACHER_NAME", "Professor"), email, password, "PROFESSOR");
            }
        }
        int port = Integer.parseInt(env("LUMIA_PORT", "8080"));
        server.start(port);
        System.out.println(
                "LumIA em http://127.0.0.1:"
                        + port
                        + " — "
                        + (demo ? "DEMONSTRAÇÃO com dados fictícios" : "MariaDB"));
    }

    public HttpServer start(int port) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 32);
        server.createContext("/", this::handle);
        server.setExecutor(
                new ThreadPoolExecutor(
                        4,
                        8,
                        60,
                        TimeUnit.SECONDS,
                        new ArrayBlockingQueue<>(64),
                        new ThreadPoolExecutor.AbortPolicy()));
        server.start();
        return server;
    }

    private void createUserIfMissing(String name, String email, String password, String role)
            throws Exception {
        email = email.toLowerCase(Locale.ROOT);
        if (db.query("SELECT id FROM users WHERE email=?", email).isEmpty())
            db.insert(
                    "INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                    name,
                    email,
                    Passwords.hash(password),
                    role);
    }

    private void seedDemo() throws Exception {
        if (!db.query("SELECT id FROM courses").isEmpty()) return;
        long t =
                ((Number)
                                db.query(
                                                "SELECT id FROM users WHERE email=?",
                                                "professor@lumia.local")
                                        .get(0)
                                        .get("id"))
                        .longValue();
        long s =
                ((Number)
                                db.query("SELECT id FROM users WHERE email=?", "aluno@lumia.local")
                                        .get(0)
                                        .get("id"))
                        .longValue();
        long c =
                db.insert(
                        "INSERT INTO courses(name,teacher_id,join_code) VALUES(?,?,?)",
                        "Matemática • Turma A",
                        t,
                        "LUMIA-DEMO");
        db.update("INSERT INTO enrollments VALUES(?,?)", c, s);
        long l =
                db.insert(
                        "INSERT INTO lessons(course_id,title) VALUES(?,?)",
                        c,
                        "Equações do primeiro grau");
        db.update("INSERT INTO grades VALUES(?,?,?,?)", l, s, 4.5, true);
        db.update(
                "INSERT INTO"
                    + " feedback(lesson_id,author_id,student_id,clarity,activity,difficulty,comment)"
                    + " VALUES(?,?,?,?,?,?,?)",
                l,
                s,
                s,
                2,
                3,
                4,
                "Tive dificuldade ao isolar a incógnita.");
        db.update(
                "INSERT INTO"
                    + " feedback(lesson_id,author_id,student_id,clarity,activity,difficulty,comment)"
                    + " VALUES(?,?,?,?,?,?,?)",
                l,
                t,
                s,
                3,
                3,
                4,
                "Retomar operações inversas com exemplos.");
    }

    private static void validateEmail(String s) {
        if (s.length() > 190 || !s.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))
            throw new IllegalArgumentException("E-mail inválido.");
    }

    private static void validatePassword(String s) {
        if (s.length() < 10 || s.length() > 128)
            throw new IllegalArgumentException("Use uma senha com 10 a 128 caracteres.");
    }

    private static String password(JsonObject body) {
        if (!body.has("password")) throw new IllegalArgumentException("Informe a senha.");
        return body.get("password").getAsString();
    }

    private void rate(String key, int max, long interval) {
        long now = System.currentTimeMillis();
        attempts.entrySet().removeIf(e -> now >= e.getValue().until);
        Attempt a =
                attempts.compute(
                        key,
                        (k, v) ->
                                v == null || now >= v.until
                                        ? new Attempt(1, now + interval)
                                        : new Attempt(Math.min(v.count + 1, max + 1), v.until));
        if (a.count > max) throw new HttpError(429, "Muitas tentativas. Aguarde alguns minutos.");
    }

    private Session auth(HttpExchange x) throws Exception {
        String token = x.getRequestHeaders().getFirst("Authorization");
        if (token == null || !token.startsWith("Bearer "))
            throw new HttpError(401, "Entre na sua conta.");
        Session s = sessions.get(token.substring(7));
        if (s == null || s.until < Instant.now().getEpochSecond()) {
            sessions.remove(token.substring(7));
            throw new HttpError(401, "Sessão expirada. Entre novamente.");
        }
        var rows = db.query("SELECT role,status,must_change_password FROM users WHERE id=?", s.id);
        if (rows.isEmpty()
                || !"ATIVO".equals(rows.get(0).get("status"))
                || !s.role.equals(rows.get(0).get("role"))) {
            revokeSessions(s.id);
            throw new HttpError(401, "Conta indisponível. Procure o ADM/TI.");
        }
        String path = x.getRequestURI().getPath();
        if (AdminService.flag(rows.get(0).get("must_change_password"))
                && !Set.of("/change-password", "/logout").contains(path))
            throw new HttpError(403, "Troque sua senha temporária antes de continuar.");
        return s;
    }

    private static void teacher(Session s) {
        if (!s.role.equals("PROFESSOR")) throw new HttpError(403, "Ação exclusiva do professor.");
    }

    private void courseAccess(Session s, long course) throws Exception {
        boolean allowed =
                s.role.equals("PROFESSOR")
                        ? !db.query(
                                        "SELECT id FROM courses WHERE id=? AND teacher_id=?",
                                        course,
                                        s.id)
                                .isEmpty()
                        : !db.query(
                                        "SELECT course_id FROM enrollments WHERE course_id=? AND"
                                            + " student_id=?",
                                        course,
                                        s.id)
                                .isEmpty();
        if (!allowed) throw new HttpError(403, "Você não tem acesso a esta matéria.");
    }

    private void enrolled(long course, long student) throws Exception {
        if (db.query(
                        "SELECT student_id FROM enrollments WHERE course_id=? AND student_id=?",
                        course,
                        student)
                .isEmpty()) throw new HttpError(400, "Aluno não matriculado nesta matéria.");
    }

    private long lessonAccess(Session s, long lesson) throws Exception {
        var rows = db.query("SELECT course_id FROM lessons WHERE id=?", lesson);
        if (rows.isEmpty()) throw new HttpError(404, "Aula não encontrada.");
        long c = ((Number) rows.get(0).get("course_id")).longValue();
        courseAccess(s, c);
        return c;
    }

    private JsonObject body(HttpExchange x) throws Exception {
        byte[] bytes = x.getRequestBody().readNBytes(32769);
        if (bytes.length > 32768) throw new HttpError(413, "Dados muito extensos.");
        try {
            return JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8))
                    .getAsJsonObject();
        } catch (Exception e) {
            throw new IllegalArgumentException("Dados inválidos.");
        }
    }

    private JsonObject query(HttpExchange x) {
        JsonObject q = new JsonObject();
        String raw = x.getRequestURI().getRawQuery();
        if (raw != null)
            for (String part : raw.split("&")) {
                String[] p = part.split("=", 2);
                if (p.length == 2)
                    q.addProperty(
                            URLDecoder.decode(p[0], StandardCharsets.UTF_8),
                            URLDecoder.decode(p[1], StandardCharsets.UTF_8));
            }
        return q;
    }

    private void handle(HttpExchange x) {
        try {
            Object result = route(x);
            send(x, 200, result);
        } catch (HttpError e) {
            send(x, e.status, Json.map("error", e.getMessage()));
        } catch (SecurityException e) {
            send(x, 403, Json.map("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            send(x, 400, Json.map("error", e.getMessage()));
        } catch (java.sql.SQLException e) {
            boolean duplicate = "23505".equals(e.getSQLState()) || e.getErrorCode() == 1062;
            send(
                    x,
                    duplicate ? 409 : 500,
                    Json.map(
                            "error",
                            duplicate
                                    ? "Este registro já existe."
                                    : "Não foi possível salvar ou consultar os dados."));
            if (!duplicate) System.err.println("Falha SQL; estado=" + e.getSQLState());
        } catch (Exception e) {
            send(x, 500, Json.map("error", "Não foi possível concluir. Tente novamente."));
            System.err.println("Falha interna: " + e.getClass().getSimpleName());
        } finally {
            x.close();
        }
    }

    private void send(HttpExchange x, int status, Object data) {
        try {
            byte[] bytes = Json.GSON.toJson(data).getBytes(StandardCharsets.UTF_8);
            x.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
            x.getResponseHeaders().set("Cache-Control", "no-store");
            x.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            x.sendResponseHeaders(status, bytes.length);
            x.getResponseBody().write(bytes);
        } catch (Exception ignored) {
        }
    }

    private Object route(HttpExchange x) throws Exception {
        String path = x.getRequestURI().getPath(), method = x.getRequestMethod();
        JsonObject q = query(x);
        if (path.equals("/health") && method.equals("GET")) return Json.map("status", "ok");
        if (path.equals("/reset-password") && method.equals("POST")) {
            return resetPassword(x);
        }
        if ((path.equals("/register") || path.equals("/login")) && method.equals("POST")) {
            return loginOrRegister(x, path);
        }
        Session s = auth(x);
        if (path.equals("/logout") && method.equals("POST")) {
            sessions.remove(x.getRequestHeaders().getFirst("Authorization").substring(7));
            return Json.map("message", "Você saiu.");
        }
        if (path.equals("/change-password") && method.equals("POST")) {
            return changePassword(x, s);
        }
        if (path.startsWith("/admin/")) {
            if (!s.role.equals("ADM")) throw new HttpError(403, "Acesso exclusivo do ADM/TI.");
            return admin.handle(s.id, path, method, method.equals("POST") ? body(x) : q);
        }
        if (s.role.equals("ADM"))
            throw new HttpError(403, "Use o painel administrativo para esta conta.");
        if (path.equals("/courses") && method.equals("GET")) {
            return listCourses(s);
        }
        if (path.equals("/courses") && method.equals("POST")) {
            return createCourse(x, s);
        }
        if (path.equals("/join") && method.equals("POST")) {
            return joinCourse(x, s);
        }
        if (path.equals("/students") && method.equals("GET")) {
            return listStudents(q, s);
        }
        if (path.equals("/lessons") && method.equals("GET")) {
            return listLessons(q, s);
        }
        if (path.equals("/lessons") && method.equals("POST")) {
            return createLesson(x, s);
        }
        if ((path.equals("/grades") || path.equals("/feedback")) && method.equals("GET")) {
            return listRecords(q, s, path);
        }
        if (path.equals("/grades") && method.equals("POST")) {
            return saveGrade(x, s);
        }
        if (path.equals("/feedback") && method.equals("POST")) {
            return saveFeedback(x, s);
        }
        if (path.equals("/overview") && method.equals("GET")) {
            return classOverview(q, s);
        }
        if (path.equals("/recommendations") && method.equals("POST")) {
            return recommend(x, s);
        }
        throw new HttpError(404, "Operação não encontrada.");
    }

    /** Valida e consome o código de redefinição. */
    private Object resetPassword(HttpExchange x) throws Exception {

        rate("reset:" + x.getRemoteAddress().getAddress().getHostAddress(), 10, 300_000);
        JsonObject b = body(x);
        String email = AdminService.email(b),
                code = Json.required(b, "code", 100),
                newPassword = password(b);
        validatePassword(newPassword);
        var rows = db.query("SELECT id FROM users WHERE email=? AND status='ATIVO'", email);
        if (rows.isEmpty())
            throw new HttpError(400, "Código inválido, expirado ou conta indisponível.");
        long id = ((Number) rows.get(0).get("id")).longValue();
        // Verifica o código antes do hash lento e consome atomicamente na transação.
        String digest = AdminService.digest(code);
        if (db.query(
                        "SELECT user_id FROM password_resets WHERE user_id=? AND token_hash=? AND"
                            + " expires_at>?",
                        id,
                        digest,
                        System.currentTimeMillis())
                .isEmpty())
            throw new HttpError(400, "Código inválido, expirado ou conta indisponível.");
        if (!db.redeemReset(id, digest, Passwords.hash(newPassword), System.currentTimeMillis()))
            throw new HttpError(400, "Código inválido, expirado ou conta indisponível.");
        revokeSessions(id);
        db.insert(
                "INSERT INTO audit_log(actor_id,action,target_id) VALUES(?,'REDEFINIR_SENHA',?)",
                id,
                id);
        return Json.map("message", "Senha redefinida. Entre com a nova senha.");
    }

    /** Recebe as credenciais e encaminha para cadastro ou login. */
    private Object loginOrRegister(HttpExchange x, String path) throws Exception {

        rate(x.getRemoteAddress().getAddress().getHostAddress(), 30, 300_000);
        JsonObject b = body(x);
        String email = Json.required(b, "email", 190).toLowerCase(Locale.ROOT);
        validateEmail(email);
        String password = password(b);
        validatePassword(password);
        if (path.equals("/register")) {
            String name = Json.required(b, "name", 120);
            db.insert(
                    "INSERT INTO users(name,email,password_hash,role,status) VALUES(?,?,?,?,?)",
                    name,
                    email,
                    Passwords.hash(password),
                    "ALUNO",
                    "PENDENTE");
            return Json.map(
                    "message", "Cadastro recebido. Aguarde a aprovação do ADM/TI para entrar.");
        }
        var rows = db.query("SELECT * FROM users WHERE email=?", email);
        boolean valid =
                Passwords.verify(
                        password,
                        rows.isEmpty() ? dummyHash : rows.get(0).get("password_hash").toString());
        if (rows.isEmpty() || !valid) throw new HttpError(401, "E-mail ou senha incorretos.");
        var row = rows.get(0);
        if (!"ATIVO".equals(row.get("status")))
            throw new HttpError(403, "Conta pendente ou desativada. Procure o ADM/TI.");
        byte[] random = new byte[32];
        new SecureRandom().nextBytes(random);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(random);
        sessions.entrySet().removeIf(e -> e.getValue().until < Instant.now().getEpochSecond());
        Session s =
                new Session(
                        ((Number) row.get("id")).longValue(),
                        row.get("name").toString(),
                        row.get("role").toString(),
                        Instant.now().getEpochSecond() + 7200);
        sessions.put(token, s);
        return Json.map(
                "token",
                token,
                "id",
                s.id,
                "name",
                s.name,
                "role",
                s.role,
                "mustChangePassword",
                AdminService.flag(row.get("must_change_password")));
    }

    /** Troca a senha e encerra as sessões antigas. */
    private Object changePassword(HttpExchange x, Session s) throws Exception {

        JsonObject b = body(x);
        String current = b.has("currentPassword") ? b.get("currentPassword").getAsString() : "",
                newPassword = password(b);
        validatePassword(newPassword);
        rate("password:" + s.id, 10, 300_000);
        var row = db.query("SELECT password_hash FROM users WHERE id=?", s.id).get(0);
        if (!Passwords.verify(current, row.get("password_hash").toString()))
            throw new HttpError(400, "Senha atual incorreta.");
        if (current.equals(newPassword))
            throw new IllegalArgumentException("Escolha uma senha diferente da temporária/atual.");
        String hash = Passwords.hash(newPassword);
        db.transaction(tx -> {
            if (tx.update("UPDATE users SET password_hash=?,must_change_password=FALSE WHERE id=? AND password_hash=? AND status='ATIVO'",
                    hash, s.id, row.get("password_hash")) != 1)
                throw new SecurityException("A conta mudou durante a operação. Entre novamente.");
            tx.update("DELETE FROM password_resets WHERE user_id=?", s.id);
            tx.insert("INSERT INTO audit_log(actor_id,action,target_id) VALUES(?,'TROCAR_SENHA',?)", s.id, s.id);
            return null;
        });
        revokeSessions(s.id);
        return Json.map("message", "Senha alterada. Entre novamente.");
    }

    /** Lista somente as matérias permitidas para a conta. */
    private Object listCourses(Session s) throws Exception {

        if (s.role.equals("PROFESSOR"))
            return db.query(
                    "SELECT id,name,join_code FROM courses WHERE teacher_id=? ORDER BY name", s.id);
        return db.query(
                "SELECT c.id,c.name FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE"
                    + " e.student_id=? ORDER BY c.name",
                s.id);
    }

    /** Professor cria uma matéria e seu código de matrícula. */
    private Object createCourse(HttpExchange x, Session s) throws Exception {

        teacher(s);
        JsonObject b = body(x);
        String name = Json.required(b, "name", 120);
        String code =
                UUID.randomUUID()
                        .toString()
                        .replace("-", "")
                        .substring(0, 12)
                        .toUpperCase(Locale.ROOT);
        db.insert("INSERT INTO courses(name,teacher_id,join_code) VALUES(?,?,?)", name, s.id, code);
        return Json.map("message", "Matéria criada. Código para matrícula: " + code);
    }

    /** Aluno se matricula por código. */
    private Object joinCourse(HttpExchange x, Session s) throws Exception {

        if (!s.role.equals("ALUNO"))
            throw new HttpError(403, "Somente alunos podem se matricular.");
        String code = Json.required(body(x), "code", 24).toUpperCase(Locale.ROOT);
        var rows = db.query("SELECT id FROM courses WHERE join_code=?", code);
        if (rows.isEmpty()) throw new HttpError(404, "Código não encontrado.");
        db.update("INSERT INTO enrollments VALUES(?,?)", rows.get(0).get("id"), s.id);
        return Json.map("message", "Matrícula concluída.");
    }

    /** Professor consulta alunos da própria matéria. */
    private Object listStudents(JsonObject q, Session s) throws Exception {

        teacher(s);
        long c = Json.id(q, "courseId");
        courseAccess(s, c);
        return db.query(
                "SELECT u.id,u.name,u.email FROM users u JOIN enrollments e ON e.student_id=u.id"
                    + " WHERE e.course_id=? ORDER BY u.name",
                c);
    }

    /** Consulta aulas da matéria selecionada. */
    private Object listLessons(JsonObject q, Session s) throws Exception {
        long c = Json.id(q, "courseId");
        courseAccess(s, c);
        return db.query("SELECT id,title FROM lessons WHERE course_id=? ORDER BY id DESC", c);
    }

    /** Professor cadastra uma aula ou atividade. */
    private Object createLesson(HttpExchange x, Session s) throws Exception {

        teacher(s);
        JsonObject b = body(x);
        long c = Json.id(b, "courseId");
        courseAccess(s, c);
        db.insert(
                "INSERT INTO lessons(course_id,title) VALUES(?,?)",
                c,
                Json.required(b, "title", 160));
        return Json.map("message", "Aula / atividade criada.");
    }

    /** Consulta notas ou feedbacks com filtro de acesso. */
    private Object listRecords(JsonObject q, Session s, String path) throws Exception {

        long c = Json.id(q, "courseId");
        courseAccess(s, c);
        String restriction = s.role.equals("ALUNO") ? " AND g.student_id=?" : "";
        Object[] args = s.role.equals("ALUNO") ? new Object[] {c, s.id} : new Object[] {c};
        if (path.equals("/grades"))
            return db.query(
                    "SELECT u.name AS aluno,l.title AS aula,g.grade AS nota,g.delivered AS entregue"
                        + " FROM grades g JOIN lessons l ON l.id=g.lesson_id JOIN users u ON"
                        + " u.id=g.student_id WHERE l.course_id=?"
                            + restriction
                            + " ORDER BY l.id,u.name",
                    args);
        return db.query(
                "SELECT u.name AS aluno,a.role AS autor,l.title AS aula,g.clarity AS"
                    + " clareza,g.activity AS atividade,g.difficulty AS dificuldade,g.comment AS"
                    + " comentario FROM feedback g JOIN lessons l ON l.id=g.lesson_id JOIN users u"
                    + " ON u.id=g.student_id JOIN users a ON a.id=g.author_id WHERE l.course_id=?"
                        + restriction
                        + " ORDER BY g.id DESC",
                args);
    }

    /** Valida nota, professor e matrícula antes de salvar. */
    private Object saveGrade(HttpExchange x, Session s) throws Exception {

        teacher(s);
        JsonObject b = body(x);
        long lesson = Json.id(b, "lessonId"),
                student = Json.id(b, "studentId"),
                c = lessonAccess(s, lesson);
        enrolled(c, student);
        double grade = Double.parseDouble(Json.text(b, "grade").replace(',', '.'));
        if (!Double.isFinite(grade) || grade < 0 || grade > 10)
            throw new IllegalArgumentException("Nota deve estar entre 0 e 10.");
        boolean delivered = b.has("delivered") && b.get("delivered").getAsBoolean();
        db.update(
                "INSERT INTO grades(lesson_id,student_id,grade,delivered) VALUES(?,?,?,?) ON"
                    + " DUPLICATE KEY UPDATE grade=VALUES(grade),delivered=VALUES(delivered)",
                lesson,
                student,
                grade,
                delivered);
        return Json.map("message", "Nota salva.");
    }

    /** Salva o relato associado à aula e ao aluno. */
    private Object saveFeedback(HttpExchange x, Session s) throws Exception {

        JsonObject b = body(x);
        long lesson = Json.id(b, "lessonId"), c = lessonAccess(s, lesson);
        long student = s.role.equals("ALUNO") ? s.id : Json.id(b, "studentId");
        enrolled(c, student);
        int clarity = Integer.parseInt(Json.text(b, "clarity")),
                activity = Integer.parseInt(Json.text(b, "activity")),
                difficulty = Integer.parseInt(Json.text(b, "difficulty"));
        if (clarity < 1
                || clarity > 5
                || activity < 1
                || activity > 5
                || difficulty < 1
                || difficulty > 5)
            throw new IllegalArgumentException("Avaliações devem estar entre 1 e 5.");
        String comment = Json.required(b, "comment", 1500);
        db.update(
                "INSERT INTO"
                    + " feedback(lesson_id,author_id,student_id,clarity,activity,difficulty,comment)"
                    + " VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE"
                    + " clarity=VALUES(clarity),activity=VALUES(activity),difficulty=VALUES(difficulty),comment=VALUES(comment)",
                lesson,
                s.id,
                student,
                clarity,
                activity,
                difficulty,
                comment);
        return Json.map("message", "Feedback salvo. Um novo envio atualiza seu relato desta aula.");
    }

    /** Calcula o resumo da turma nesta matéria. */
    private Object classOverview(JsonObject q, Session s) throws Exception {

        teacher(s);
        long c = Json.id(q, "courseId");
        courseAccess(s, c);
        var rows =
                db.query(
                        "SELECT u.name,AVG(g.grade) AS media,COUNT(g.grade) AS quantidade FROM"
                            + " enrollments e JOIN users u ON u.id=e.student_id LEFT JOIN lessons l"
                            + " ON l.course_id=e.course_id LEFT JOIN grades g ON g.lesson_id=l.id"
                            + " AND g.student_id=e.student_id WHERE e.course_id=? GROUP BY"
                            + " u.id,u.name ORDER BY u.name",
                        c);
        StringBuilder out = new StringBuilder("RESUMO DA TURMA NESTA MATÉRIA\n\n");
        int attention = 0, excellent = 0, withGrades = 0;
        double total = 0;
        for (var row : rows) {
            out.append(row.get("name")).append(": ");
            if (row.get("media") == null) out.append("sem notas registradas\n");
            else {
                double avg = ((Number) row.get("media")).doubleValue();
                total += avg;
                withGrades++;
                out.append(String.format(Locale.forLanguageTag("pt-BR"), "%.1f", avg));
                if (avg < 6) {
                    attention++;
                    out.append(" — precisa de atenção");
                } else if (avg >= 8.5) {
                    excellent++;
                    out.append(" — desempenho elevado nas atividades registradas");
                }
                out.append('\n');
            }
        }
        out.append("\nMatriculados: ")
                .append(rows.size())
                .append("\nCom notas: ")
                .append(withGrades)
                .append("\nAbaixo de 6: ")
                .append(attention)
                .append("\nMédia a partir de 8,5: ")
                .append(excellent);
        if (withGrades > 0)
            out.append(
                    String.format(
                            Locale.forLanguageTag("pt-BR"),
                            "\nMédia das médias individuais: %.1f",
                            total / withGrades));
        if (attention > 0)
            out.append(
                    "\n\n"
                        + "Proposta: revisar as dificuldades nas atividades e comparar os relatos"
                        + " de aluno e professor antes de definir a intervenção.");
        out.append(
                "\n\n"
                    + "Sem nota não significa zero. Classificações usam os valores antes do"
                    + " arredondamento.");
        return Json.map("text", out.toString());
    }

    /** Valida acesso e limite de uso antes de recomendar. */
    private Object recommend(HttpExchange x, Session s) throws Exception {

        JsonObject b = body(x);
        long student = s.role.equals("ALUNO") ? s.id : Json.id(b, "studentId");
        if (s.role.equals("PROFESSOR")
                && db.query(
                                "SELECT e.student_id FROM enrollments e JOIN courses c ON"
                                    + " c.id=e.course_id WHERE e.student_id=? AND c.teacher_id=?",
                                student,
                                s.id)
                        .isEmpty())
            throw new HttpError(403, "Aluno não vinculado às suas matérias.");
        boolean ai = b.has("useAi") && b.get("useAi").getAsBoolean();
        if (ai) {
            long now = System.currentTimeMillis();
            synchronized (aiCalls) {
                aiCalls.entrySet().removeIf(e -> now - e.getValue() >= 30_000);
                Long last = aiCalls.get(s.id);
                if (last != null && now - last < 30_000)
                    throw new HttpError(
                            429, "Aguarde 30 segundos antes de consultar a IA novamente.");
                aiCalls.put(s.id, now);
            }
        }
        return Recommendations.build(db, student, s.role.equals("PROFESSOR") ? s.id : null, ai);
    }
}
