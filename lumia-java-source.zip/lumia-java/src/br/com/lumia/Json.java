package br.com.lumia;

import com.google.gson.*;

import java.util.*;

/** Contrato comum entre aplicativo e servidor; não contém credenciais. */
public final class Json {
    public static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

    private Json() {}

    public static String text(JsonObject o, String key) {
        if (!o.has(key) || !o.get(key).isJsonPrimitive())
            throw new IllegalArgumentException("Campo obrigatório: " + key);
        return o.get(key).getAsString().trim();
    }

    public static String required(JsonObject o, String key, int max) {
        String v = text(o, key);
        if (v.isBlank() || v.length() > max)
            throw new IllegalArgumentException("Confira o campo " + key + ".");
        return v;
    }

    public static long id(JsonObject o, String key) {
        try {
            long v = Long.parseLong(text(o, key));
            if (v < 1) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Identificador inválido: " + key);
        }
    }

    public static Map<String, Object> map(Object... pairs) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) m.put((String) pairs[i], pairs[i + 1]);
        return m;
    }
}
