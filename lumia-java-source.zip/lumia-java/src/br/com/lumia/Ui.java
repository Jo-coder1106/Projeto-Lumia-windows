package br.com.lumia;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Aparência e campos comuns às telas. Não contém acesso a dados. */
final class Ui {
    private Ui() {}

    static final Color BLUE = new Color(18, 57, 87),
            BG = new Color(243, 247, 250),
            GOLD = new Color(182, 141, 61);

    record Item(long id, String label, String code) {
        public String toString() {
            return label;
        }
    }

    static JPanel page() {
        JPanel p = new JPanel(new BorderLayout(18, 18));
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(24, 30, 24, 30));
        return p;
    }

    static JButton button(String label, Runnable action) {
        JButton b = new JButton(label);
        b.setFocusPainted(false);
        b.addActionListener(e -> action.run());
        return b;
    }

    static JPanel form() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        return p;
    }

    static void field(JPanel p, String label, JComponent component) {
        JLabel l = new JLabel(label);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(l);
        p.add(Box.createVerticalStrut(6));
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        p.add(component);
        p.add(Box.createVerticalStrut(16));
    }

    static JLabel heading(String title) {
        JLabel l = new JLabel(title);
        l.setFont(new Font("SansSerif", Font.BOLD, 25));
        l.setForeground(BLUE);
        return l;
    }

    static Item selected(JComboBox<Item> box, String what) {
        Item item = (Item) box.getSelectedItem();
        if (item == null) throw new IllegalArgumentException("Selecione " + what + ".");
        return item;
    }
}
