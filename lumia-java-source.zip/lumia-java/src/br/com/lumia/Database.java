package br.com.lumia;

import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

/** SQL parametrizado: valores do usuário nunca são concatenados à consulta. */
public final class Database {
    private final String url, user, password;

    public Database(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    // ---- Núcleo JDBC: recebe a Connection, assim serve tanto para consultas avulsas
    // ---- quanto para dentro de uma transação.

    private static void bind(PreparedStatement st, Object... args) throws SQLException {
        for (int i = 0; i < args.length; i++) st.setObject(i + 1, args[i]);
    }

    private static List<Map<String, Object>> query(Connection c, String sql, Object... args)
            throws SQLException {
        try (PreparedStatement st = c.prepareStatement(sql)) {
            bind(st, args);
            try (ResultSet rs = st.executeQuery()) {
                List<Map<String, Object>> result = new ArrayList<>();
                ResultSetMetaData metadata = rs.getMetaData();
                int columnCount = metadata.getColumnCount();
                String[] columnNames = new String[columnCount];
                for (int i = 0; i < columnCount; i++)
                    columnNames[i] = metadata.getColumnLabel(i + 1).toLowerCase(Locale.ROOT);
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 0; i < columnCount; i++)
                        row.put(columnNames[i], rs.getObject(i + 1));
                    result.add(row);
                }
                return result;
            }
        }
    }

    private static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement st = c.prepareStatement(sql)) {
            bind(st, args);
            return st.executeUpdate();
        }
    }

    private static long insert(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement st = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(st, args);
            st.executeUpdate();
            try (ResultSet rs = st.getGeneratedKeys()) {
                if (rs.next()) return rs.getLong(1);
                throw new SQLException("ID indisponível");
            }
        }
    }

    // ---- API pública para operações avulsas (cada chamada = uma conexão = auto-commit).

    public List<Map<String, Object>> query(String sql, Object... args) throws SQLException {
        try (Connection c = connect()) {
            return query(c, sql, args);
        }
    }

    public int update(String sql, Object... args) throws SQLException {
        try (Connection c = connect()) {
            return update(c, sql, args);
        }
    }

    public long insert(String sql, Object... args) throws SQLException {
        try (Connection c = connect()) {
            return insert(c, sql, args);
        }
    }

    // ---- Transações

    /** Operações executadas dentro de uma transação. Use apenas dentro de {@link #transaction}. */
    public static final class Tx {
        private final Connection c;

        private Tx(Connection c) {
            this.c = c;
        }

        public List<Map<String, Object>> query(String sql, Object... args) throws SQLException {
            return Database.query(c, sql, args);
        }

        public int update(String sql, Object... args) throws SQLException {
            return Database.update(c, sql, args);
        }

        public long insert(String sql, Object... args) throws SQLException {
            return Database.insert(c, sql, args);
        }
    }

    @FunctionalInterface
    public interface TxWork<T> {
        T run(Tx tx) throws Exception;
    }

    /**
     * Executa várias operações como uma só: se o trabalho terminar normalmente, confirma (commit);
     * se lançar qualquer exceção, desfaz tudo (rollback) e repassa a exceção.
     */
    public <T> T transaction(TxWork<T> work) throws Exception {
        try (Connection c = connect()) {
            c.setAutoCommit(false);
            try {
                T result = work.run(new Tx(c));
                c.commit();
                return result;
            } catch (Throwable e) {
                try {
                    c.rollback();
                } catch (SQLException rollbackFailure) {
                    e.addSuppressed(rollbackFailure);
                }
                throw e;
            } finally {
                // Devolve a conexão ao estado normal (importante se houver pool de conexões).
                try {
                    c.setAutoCommit(true);
                } catch (SQLException ignored) {
                    // a conexão será fechada de qualquer forma
                }
            }
        }
    }

    /** Teste rápido de conexão, usado na partida do servidor para dar um erro compreensível. */
    public void ping() throws SQLException {
        try (Connection c = connect()) {
            if (!c.isValid(5)) throw new SQLException("A conexão com o banco não respondeu.");
        }
    }

    public void initialize() throws Exception {
        try (var input = Database.class.getResourceAsStream("/schema.sql")) {
            if (input == null) throw new IllegalStateException("schema.sql ausente");
            for (String sql : new String(input.readAllBytes(), StandardCharsets.UTF_8).split(";"))
                if (!sql.isBlank()) update(sql);
        }
        migrateUsers();
    }

    /** Migração da v0.1: preserva contas e dados. Executada antes de aceitar conexões. */
    private void migrateUsers() throws Exception {
        try (Connection c = connect()) {
            boolean h2 = c.getMetaData().getDatabaseProductName().equals("H2");
            String schema = h2 ? c.getSchema() : c.getCatalog();
            var constraints =
                    query(
                            "SELECT tc.CONSTRAINT_NAME,cc.CHECK_CLAUSE FROM"
                                + " information_schema.TABLE_CONSTRAINTS tc JOIN"
                                + " information_schema.CHECK_CONSTRAINTS cc ON"
                                + " tc.CONSTRAINT_NAME=cc.CONSTRAINT_NAME AND"
                                + " tc.CONSTRAINT_SCHEMA=cc.CONSTRAINT_SCHEMA WHERE"
                                + " LOWER(tc.TABLE_NAME)='users' AND tc.CONSTRAINT_SCHEMA=? AND"
                                + " tc.CONSTRAINT_TYPE='CHECK'",
                            schema);
            for (var row : constraints) {
                String clause = row.get("check_clause").toString().toUpperCase(Locale.ROOT);
                if (clause.contains("ROLE") && !clause.contains("'ADM'")) {
                    String name = row.get("constraint_name").toString();
                    String quote = h2 ? "\"" : "`";
                    update(
                            "ALTER TABLE users DROP CONSTRAINT "
                                    + quote
                                    + name.replace(quote, quote + quote)
                                    + quote);
                }
            }
            // Se uma migração anterior interrompeu após DROP, a restrição é recriada.
            var current =
                    query(
                            "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE"
                                + " LOWER(TABLE_NAME)='users' AND CONSTRAINT_SCHEMA=? AND"
                                + " LOWER(CONSTRAINT_NAME)='ck_users_role_v2'",
                            schema);
            if (current.isEmpty())
                update(
                        "ALTER TABLE users ADD CONSTRAINT ck_users_role_v2 CHECK (role IN"
                            + " ('ALUNO','PROFESSOR','ADM'))");
            Set<String> columns = new HashSet<>();
            try (ResultSet rs =
                    c.getMetaData().getColumns(c.getCatalog(), h2 ? schema : null, "users", null)) {
                while (rs.next()) columns.add(rs.getString("COLUMN_NAME").toLowerCase(Locale.ROOT));
            }
            if (!columns.contains("status"))
                update(
                        "ALTER TABLE users ADD COLUMN status VARCHAR(12) NOT NULL DEFAULT 'ATIVO'"
                            + " CHECK (status IN ('PENDENTE','ATIVO','INATIVO'))");
            if (!columns.contains("must_change_password"))
                update(
                        "ALTER TABLE users ADD COLUMN must_change_password BOOLEAN NOT NULL DEFAULT"
                            + " FALSE");
        }
    }

    /** Token consumido e senha alterada na mesma transação; não pode ser reutilizado. */
    public boolean redeemReset(long userId, String tokenHash, String newHash, long now)
            throws SQLException {
        try {
            return transaction(
                    tx -> {
                        if (tx.update(
                                        "DELETE FROM password_resets WHERE user_id=? AND token_hash=?"
                                            + " AND expires_at>?",
                                        userId,
                                        tokenHash,
                                        now)
                                != 1) return false;
                        if (tx.update(
                                        "UPDATE users SET password_hash=?,must_change_password=FALSE"
                                            + " WHERE id=? AND status='ATIVO'",
                                        newHash,
                                        userId)
                                != 1) {
                            // Lançar desfaz o DELETE do token: o código continua válido.
                            throw new RollbackSignal();
                        }
                        return true;
                    });
        } catch (RollbackSignal e) {
            return false;
        } catch (SQLException e) {
            throw e;
        } catch (Exception e) {
            throw new SQLException(e);
        }
    }

    /** Usada só para desfazer a transação sem tratar como erro. */
    private static final class RollbackSignal extends RuntimeException {
        RollbackSignal() {
            super(null, null, false, false);
        }
    }
}
