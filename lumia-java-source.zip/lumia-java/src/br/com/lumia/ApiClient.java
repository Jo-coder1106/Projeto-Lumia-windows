package br.com.lumia;

import com.google.gson.*;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;

/** O aplicativo conhece apenas o endereço do servidor, nunca a chave Gemini ou o banco. */
public final class ApiClient {
    public static final class ApiException extends Exception {
        public final int status;

        public ApiException(int status, String message) {
            super(message);
            this.status = status;
        }
    }

    private final HttpClient http =
            HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final String base;
    private String token = "";

    public ApiClient(String base) {
        URI uri = URI.create(base);
        boolean local = "127.0.0.1".equals(uri.getHost()) || "localhost".equals(uri.getHost());
        if (!"https".equals(uri.getScheme()) && !("http".equals(uri.getScheme()) && local))
            throw new IllegalArgumentException("Use HTTPS para servidores remotos.");
        this.base = base.replaceAll("/+$", "");
    }

    public void token(String token) {
        this.token = token;
    }

    public JsonElement get(String path) throws Exception {
        return call("GET", path, null);
    }

    public JsonElement post(String path, Object data) throws Exception {
        return call("POST", path, data);
    }

    private JsonElement call(String method, String path, Object body) throws Exception {
        var request =
                HttpRequest.newBuilder(URI.create(base + path))
                        .timeout(Duration.ofSeconds(50))
                        .header("Accept", "application/json");
        if (!token.isBlank()) request.header("Authorization", "Bearer " + token);
        if (method.equals("POST"))
            request.header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(Json.GSON.toJson(body)));
        else request.GET();
        HttpResponse<String> response;
        try {
            response = http.send(request.build(), HttpResponse.BodyHandlers.ofString());
        } catch (java.io.IOException e) {
            throw new Exception(
                    "Servidor indisponível. Inicie o servidor LumIA e tente novamente.");
        }
        JsonElement result;
        try {
            result = JsonParser.parseString(response.body());
        } catch (Exception e) {
            throw new Exception("Resposta inesperada do servidor.");
        }
        if (response.statusCode() >= 400)
            throw new ApiException(
                    response.statusCode(), result.getAsJsonObject().get("error").getAsString());
        return result;
    }
}
