package br.com.lumia;

import static br.com.lumia.Ui.*;

import com.google.gson.*;

import java.awt.*;
import java.util.List;

import javax.swing.*;

/** Tela ADM/TI. As permissões continuam sendo verificadas no servidor. */
public final class AdminPanel extends JPanel {
    private final Desktop app;
    private final ApiClient api;
    private final JFrame frame;

    public AdminPanel(Desktop app) {
        this.app = app;
        this.api = app.api;
        this.frame = app.frame;
        setLayout(new BorderLayout());
        add(buildPanel());
    }

    private JTable adminTable;
    private JTabbedPane adminTabs;
    private List<JsonArray> adminData =
            List.of(new JsonArray(), new JsonArray(), new JsonArray(), new JsonArray());

    private JPanel buildPanel() {
        JPanel p = page(), top = form();
        top.add(heading("LumIA • Administração / TI"));
        top.add(Box.createVerticalStrut(10));
        top.add(new JLabel("Contas, aprovações, matérias/turmas e matrículas"));
        p.add(top, BorderLayout.NORTH);
        adminTable = new JTable();
        adminTable.setRowHeight(30);
        adminTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        adminTable.setAutoCreateRowSorter(true);
        adminTabs = new JTabbedPane();
        for (String title : new String[] {"Contas", "Matérias / turmas", "Matrículas", "Histórico"})
            adminTabs.addTab(title, new JPanel());
        adminTabs.setPreferredSize(new Dimension(900, 36));
        JPanel center = new JPanel(new BorderLayout(0, 12));
        center.setOpaque(false);
        center.add(adminTabs, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(adminTable);
        scroll.setColumnHeaderView(adminTable.getTableHeader());
        center.add(scroll);
        p.add(center);
        adminTabs.addChangeListener(e -> fillAdmin());
        JPanel actions = new JPanel(new GridLayout(0, 4, 8, 8));
        actions.setOpaque(false);
        actions.add(button("Nova conta", () -> app.safe(this::adminNewUser)));
        actions.add(button("Editar conta", () -> app.safe(this::adminEditUser)));
        actions.add(button("Aprovar / reativar", () -> app.safe(() -> adminStatus("ATIVO"))));
        actions.add(button("Desativar conta", () -> app.safe(() -> adminStatus("INATIVO"))));
        actions.add(
                button(
                        "Gerar código de senha",
                        () ->
                                app.safe(
                                        () -> {
                                            var r = adminSelected(0);
                                            adminPost(
                                                    "/admin/password-reset",
                                                    Json.map("id", r.get("id").getAsLong()));
                                        })));
        actions.add(button("Nova matéria / turma", () -> app.safe(() -> adminCourse(false))));
        actions.add(button("Editar matéria / turma", () -> app.safe(() -> adminCourse(true))));
        actions.add(button("Matricular aluno", () -> app.safe(this::adminEnroll)));
        actions.add(
                button(
                        "Remover matrícula",
                        () ->
                                app.safe(
                                        () -> {
                                            var r = adminSelected(2);
                                            if (JOptionPane.showConfirmDialog(
                                                            frame,
                                                            "Remover esta matrícula? Notas e"
                                                                + " feedbacks históricos serão"
                                                                + " preservados.",
                                                            "Confirmar",
                                                            JOptionPane.OK_CANCEL_OPTION)
                                                    == JOptionPane.OK_OPTION)
                                                adminPost(
                                                        "/admin/enrollment-remove",
                                                        Json.map(
                                                                "courseId",
                                                                r.get("course_id").getAsLong(),
                                                                "studentId",
                                                                r.get("student_id").getAsLong()));
                                        })));
        actions.add(button("Atualizar", this::loadAdmin));
        actions.add(button("Trocar minha senha", () -> app.showPassword(false)));
        actions.add(button("Sair", app::logout));
        JPanel bottom = new JPanel(new BorderLayout(0, 10));
        bottom.setOpaque(false);
        bottom.add(actions);
        app.status = new JLabel("Selecione a aba e a linha antes de editar.");
        bottom.add(app.status, BorderLayout.SOUTH);
        p.add(bottom, BorderLayout.SOUTH);
        fillAdmin();
        return p;
    }

    void loadAdmin() {
        app.task(
                () ->
                        List.of(
                                api.get("/admin/users").getAsJsonArray(),
                                api.get("/admin/courses").getAsJsonArray(),
                                api.get("/admin/enrollments").getAsJsonArray(),
                                api.get("/admin/audit").getAsJsonArray()),
                r -> {
                    adminData = r;
                    fillAdmin();
                });
    }

    private void fillAdmin() {
        int tab = adminTabs.getSelectedIndex();
        String[][] keys = {
            {"id", "name", "email", "role", "status"},
            {"id", "name", "teacher", "join_code"},
            {"course_id", "course", "student_id", "student"},
            {"id", "actor", "action", "target_id", "created_at"}
        };
        String[][] labels = {
            {"ID", "Nome", "E-mail", "Perfil", "Situação"},
            {"ID", "Matéria / turma", "Professor", "Código"},
            {"Turma ID", "Matéria / turma", "Aluno ID", "Aluno"},
            {"ID", "Responsável", "Ação", "Registro ID", "Data"}
        };
        var model =
                new javax.swing.table.DefaultTableModel(labels[tab], 0) {
                    public boolean isCellEditable(int row, int col) {
                        return false;
                    }
                };
        for (var element : adminData.get(tab)) {
            var r = element.getAsJsonObject();
            Object[] values = new Object[keys[tab].length];
            for (int i = 0; i < values.length; i++)
                values[i] =
                        r.has(keys[tab][i]) && !r.get(keys[tab][i]).isJsonNull()
                                ? r.get(keys[tab][i]).getAsString()
                                : "";
            model.addRow(values);
        }
        adminTable.setModel(model);
    }

    private JsonObject adminSelected(int tab) {
        if (adminTabs.getSelectedIndex() != tab)
            throw new IllegalArgumentException("Selecione a aba adequada à operação.");
        int row = adminTable.getSelectedRow();
        if (row < 0) throw new IllegalArgumentException("Selecione uma linha da tabela.");
        return adminData.get(tab).get(adminTable.convertRowIndexToModel(row)).getAsJsonObject();
    }

    private void adminPost(String path, Object data) {
        app.task(
                () -> api.post(path, data).getAsJsonObject(),
                r -> {
                    if (r.has("temporaryPassword") || r.has("resetCode")) {
                        String key = r.has("temporaryPassword") ? "temporaryPassword" : "resetCode";
                        JTextArea text =
                                new JTextArea(
                                        r.get("message").getAsString()
                                                + "\n\n"
                                                + r.get(key).getAsString(),
                                        5,
                                        55);
                        text.setEditable(false);
                        text.setLineWrap(true);
                        text.setWrapStyleWord(true);
                        JOptionPane.showMessageDialog(
                                frame,
                                new JScrollPane(text),
                                "Copie e entregue somente ao titular",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                    loadAdmin();
                });
    }

    private void adminNewUser() {
        JPanel f = form();
        JTextField name = new JTextField(), email = new JTextField();
        JComboBox<String> role = new JComboBox<>(new String[] {"ALUNO", "PROFESSOR", "ADM"});
        field(f, "Nome", name);
        field(f, "E-mail", email);
        field(f, "Perfil", role);
        if (JOptionPane.showConfirmDialog(
                        frame,
                        f,
                        "Nova conta — senha temporária gerada pelo sistema",
                        JOptionPane.OK_CANCEL_OPTION)
                != JOptionPane.OK_OPTION) return;
        if ("ADM".equals(role.getSelectedItem())
                && JOptionPane.showConfirmDialog(
                                frame,
                                "Esta conta poderá administrar outras contas e turmas. Autorizar?",
                                "Novo ADM/TI",
                                JOptionPane.YES_NO_OPTION)
                        != JOptionPane.YES_OPTION) return;
        adminPost(
                "/admin/users",
                Json.map(
                        "name",
                        name.getText(),
                        "email",
                        email.getText(),
                        "role",
                        role.getSelectedItem()));
    }

    private void adminEditUser() {
        var r = adminSelected(0);
        JPanel f = form();
        JTextField name = new JTextField(r.get("name").getAsString()),
                email = new JTextField(r.get("email").getAsString());
        field(f, "Nome", name);
        field(f, "E-mail", email);
        if (JOptionPane.showConfirmDialog(
                        frame,
                        f,
                        "Editar conta — encerra as sessões dessa conta",
                        JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION)
            adminPost(
                    "/admin/user-edit",
                    Json.map(
                            "id",
                            r.get("id").getAsLong(),
                            "name",
                            name.getText(),
                            "email",
                            email.getText()));
    }

    private void adminStatus(String status) {
        var r = adminSelected(0);
        if (JOptionPane.showConfirmDialog(
                        frame,
                        "Alterar " + r.get("name").getAsString() + " para " + status + "?",
                        "Confirmar",
                        JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION)
            adminPost(
                    "/admin/user-status",
                    Json.map("id", r.get("id").getAsLong(), "status", status));
    }

    private JComboBox<Item> adminPeople(String role) {
        JComboBox<Item> box = new JComboBox<>();
        for (var e : adminData.get(0)) {
            var r = e.getAsJsonObject();
            if (r.get("role").getAsString().equals(role)
                    && r.get("status").getAsString().equals("ATIVO"))
                box.addItem(
                        new Item(
                                r.get("id").getAsLong(),
                                r.get("name").getAsString() + " • " + r.get("email").getAsString(),
                                ""));
        }
        return box;
    }

    private void adminCourse(boolean edit) {
        var r = edit ? adminSelected(1) : new JsonObject();
        JPanel f = form();
        JTextField name = new JTextField(edit ? r.get("name").getAsString() : "");
        JComboBox<Item> teacher = adminPeople("PROFESSOR");
        if (edit)
            for (int i = 0; i < teacher.getItemCount(); i++)
                if (teacher.getItemAt(i).id() == r.get("teacher_id").getAsLong())
                    teacher.setSelectedIndex(i);
        field(f, "Nome da matéria / turma", name);
        field(f, "Professor responsável", teacher);
        if (JOptionPane.showConfirmDialog(
                        frame,
                        f,
                        edit ? "Editar matéria / turma" : "Nova matéria / turma",
                        JOptionPane.OK_CANCEL_OPTION)
                != JOptionPane.OK_OPTION) return;
        var data =
                Json.map(
                        "name",
                        name.getText(),
                        "teacherId",
                        selected(teacher, "um professor ativo").id());
        if (edit) data.put("id", r.get("id").getAsLong());
        adminPost(edit ? "/admin/course-edit" : "/admin/courses", data);
    }

    private void adminEnroll() {
        JPanel f = form();
        JComboBox<Item> course = new JComboBox<>(), student = adminPeople("ALUNO");
        for (var e : adminData.get(1)) {
            var r = e.getAsJsonObject();
            course.addItem(new Item(r.get("id").getAsLong(), r.get("name").getAsString(), ""));
        }
        field(f, "Matéria / turma", course);
        field(f, "Aluno", student);
        if (JOptionPane.showConfirmDialog(
                        frame, f, "Matricular aluno", JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION)
            adminPost(
                    "/admin/enrollment-add",
                    Json.map(
                            "courseId",
                            selected(course, "uma matéria").id(),
                            "studentId",
                            selected(student, "um aluno ativo").id()));
    }
}
