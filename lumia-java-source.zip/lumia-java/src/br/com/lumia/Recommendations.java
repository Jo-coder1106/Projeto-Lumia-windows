package br.com.lumia;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Consulta os registros, calcula as médias e monta o plano antes de consultar a IA. */
public final class Recommendations {
    private Recommendations() {}

    public static Map<String, Object> build(Database db, long student, Long teacher, boolean useAi)
            throws Exception {
        List<Map<String, Object>> evidence = loadEvidence(db, student, teacher);
        var resources = reinforcementResources(evidence);
        String plan = buildStudyPlan(evidence, resources);
        var result =
                useAi
                        ? GeminiClient.enhance(evidence, plan)
                        : Json.map("source", "REGRAS", "text", plan);
        result.put("resources", resources);
        return result;
    }

    /** Filtro do professor e matrícula permanecem nas consultas. */
    private static List<Map<String, Object>> loadEvidence(Database db, long student, Long teacher)
            throws Exception {
        String filter = teacher == null ? "" : " AND c.teacher_id=?";
        Object[] args = teacher == null ? new Object[] {student} : new Object[] {student, teacher};
        var courses =
                db.query(
                        "SELECT c.id,c.name FROM courses c JOIN enrollments e ON e.course_id=c.id"
                                + " WHERE e.student_id=?"
                                + filter,
                        args);
        List<Map<String, Object>> evidence = new ArrayList<>();
        for (var course : courses) {
            long id = ((Number) course.get("id")).longValue();
            var grades =
                    db.query(
                            "SELECT l.title,g.grade,g.delivered FROM grades g JOIN lessons l ON"
                                    + " l.id=g.lesson_id WHERE l.course_id=? AND g.student_id=?",
                            id,
                            student);
            var feedback =
                    db.query(
                            "SELECT u.role,f.clarity,f.activity,f.difficulty,f.comment,l.title FROM"
                                + " feedback f JOIN users u ON u.id=f.author_id JOIN lessons l ON"
                                + " l.id=f.lesson_id WHERE l.course_id=? AND f.student_id=? ORDER"
                                + " BY f.id DESC LIMIT 20",
                            id,
                            student);
            double sum = 0;
            int pending = 0;
            for (var grade : grades) {
                if (AdminService.flag(grade.get("delivered")))
                    sum += ((Number) grade.get("grade")).doubleValue();
                else pending++;
            }
            Double avg = null;
            if (grades.size() > pending) avg = sum / (grades.size() - pending);
            boolean highDifficulty = false;
            for (var report : feedback) {
                if (((Number) report.get("difficulty")).intValue() >= 4) {
                    highDifficulty = true;
                    break;
                }
            }
            var item =
                    Json.map(
                            "materia",
                            course.get("name"),
                            "media",
                            avg,
                            "registros",
                            grades.size() - pending,
                            "naoEntreguesRegistradas",
                            pending,
                            "notas",
                            grades,
                            "feedbacks",
                            feedback,
                            "dificuldadeAlta",
                            highDifficulty);
            evidence.add(item);
        }
        return evidence;
    }

    /** Cálculos sem IA; dados ausentes nunca são convertidos para nota zero. */
    private static String buildStudyPlan(List<Map<String, Object>> evidence, List<Map<String, Object>> resources) {
        List<Map<String, Object>> ranked = new ArrayList<>(evidence);
        ranked.sort(
                Comparator.comparingDouble(
                        r ->
                                r.get("media") == null
                                        ? Double.POSITIVE_INFINITY
                                        : (Double) r.get("media")));
        StringBuilder text =
                new StringBuilder(
                        "PLANO DE REFORÇO — LumIA\n\n"
                            + "Notas orientam a escolha de assuntos para revisão, não classificam a"
                            + " capacidade do aluno.\n"
                            + "Converse sobre os erros, os feedbacks e as condições da atividade"
                            + " com o professor.\n\n");
        if (ranked.isEmpty()) text.append("Ainda não há matérias matriculadas para analisar.\n");
        for (var r : ranked) {
            text.append("Matéria ").append(evidence.indexOf(r) + 1).append(" do contexto — ").append(r.get("materia")).append("\n");
            if (r.get("media") == null)
                text.append(
                        "Sem notas registradas de atividades entregues: faltam dados para"
                            + " selecionar reforço por nota.\n");
            else {
                double avg = (Double) r.get("media");
                text.append(
                        String.format(
                                Locale.forLanguageTag("pt-BR"),
                                "Média simples: %.1f (%s registros).\n",
                                avg,
                                r.get("registros")));
                text.append("A média descreve estes registros; não determina proficiência.\n");
            }
            if (((Number) r.get("naoEntreguesRegistradas")).longValue() > 0)
                text.append(
                        "Há atividades registradas como não entregues; combine a recuperação com o"
                                + " professor.\n");
            if (Boolean.TRUE.equals(r.get("dificuldadeAlta")))
                text.append(
                        "Há relato de dificuldade alta: compare os feedbacks desta matéria com o"
                                + " professor para decidir o conteúdo da revisão.\n");
            text.append("\n");
        }
        text.append("REFORÇO NO YOUTUBE\n");
        if (resources.isEmpty())
            text.append("Sem atividades entregues com nota para selecionar assuntos.\n");
        for (var resource : resources) {
            text.append(resource.get("title"))
                    .append(" — nota ")
                    .append(resource.get("grade"))
                    .append("\nBusca no YouTube (vídeos não verificados): ")
                    .append(resource.get("url"))
                    .append("\n");
        }
        text.append(
                "Escolha uma explicação sobre o assunto, assista e refaça uma questão. "
                        + "Registre o que ainda ficou confuso para discutir com o professor.\n\n");
        text.append(
                "Ausência de nota não equivale a zero. Feedbacks são relatos; notas isoladas não"
                        + " explicam a causa de uma dificuldade.");
        return text.toString();
    }

    /** Até três menores notas de atividades entregues por matéria, sem classificar proficiência. */
    private static List<Map<String, Object>> reinforcementResources(
            List<Map<String, Object>> evidence) {
        List<Map<String, Object>> resources = new ArrayList<>();
        for (var course : evidence) {
            List<Map<?, ?>> grades = new ArrayList<>();
            if (course.get("notas") instanceof List<?> rows)
                for (Object row : rows) if (row instanceof Map<?, ?> grade) grades.add(grade);
            grades.removeIf(g -> !AdminService.flag(g.get("delivered")));
            grades.sort(Comparator.comparingDouble(g -> ((Number) g.get("grade")).doubleValue()));
            Set<String> topics = new HashSet<>();
            int count = 0;
            for (var grade : grades) {
                String title = String.valueOf(grade.get("title")).strip();
                if (title.isBlank() || !topics.add(title.toLowerCase(Locale.ROOT))) continue;
                String query =
                        course.get("materia")
                                + " "
                                + title
                                + " aula exercícios resolvidos português";
                resources.add(
                        Json.map(
                                "title",
                                course.get("materia") + " — " + title,
                                "grade",
                                grade.get("grade"),
                                "type",
                                "YOUTUBE_SEARCH",
                                "url",
                                "https://www.youtube.com/results?search_query="
                                        + URLEncoder.encode(query, StandardCharsets.UTF_8)));
                if (++count == 3) break;
            }
        }
        return resources;
    }
}
