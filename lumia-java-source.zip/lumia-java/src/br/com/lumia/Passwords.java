package br.com.lumia;

import java.security.*;
import java.util.*;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Sal aleatório por usuário; nunca armazena a senha original. */
public final class Passwords {
    private static final int ITERATIONS = 600_000;

    private static byte[] derive(char[] password, byte[] salt, int iterations) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec)
                    .getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Hash indisponível", e);
        } finally {
            spec.clearPassword();
        }
    }

    public static String hash(String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        char[] chars = password.toCharArray();
        try {
            return ITERATIONS
                    + ":"
                    + Base64.getEncoder().encodeToString(salt)
                    + ":"
                    + Base64.getEncoder().encodeToString(derive(chars, salt, ITERATIONS));
        } finally {
            Arrays.fill(chars, '\0');
        }
    }

    public static boolean verify(String password, String encoded) {
        String[] p = encoded.split(":");
        char[] chars = password.toCharArray();
        try {
            return MessageDigest.isEqual(
                    Base64.getDecoder().decode(p[2]),
                    derive(chars, Base64.getDecoder().decode(p[1]), Integer.parseInt(p[0])));
        } finally {
            Arrays.fill(chars, '\0');
        }
    }
}
