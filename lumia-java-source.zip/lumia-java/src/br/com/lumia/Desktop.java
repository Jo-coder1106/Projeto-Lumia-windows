package br.com.lumia;

import static br.com.lumia.Ui.*;

import com.google.gson.*;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Telas Swing. SwingWorker mantém a janela responsiva enquanto o servidor trabalha. */
public final class Desktop {

    final ApiClient api;
    JFrame frame;
    private JsonObject user;
    private JComboBox<Item> courses, lessons, students;
    private JTextArea output;
    JLabel status;
    private JLabel courseInfo;
    private boolean loading = false;

    public Desktop(String base) {
        api = new ApiClient(base);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
                () -> {
                    try {
                        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                        UIManager.put("Label.font", new Font("SansSerif", Font.PLAIN, 14));
                        UIManager.put("Button.font", new Font("SansSerif", Font.BOLD, 14));
                        new Desktop(
                                        System.getenv()
                                                .getOrDefault(
                                                        "LUMIA_SERVER_URL",
                                                        "http://127.0.0.1:8080"))
                                .open();
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                    }
                });
    }

    public void open() {
        frame = new JFrame("LumIA • Acompanhamento acadêmico");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1080, 740));
        frame.setSize(1100, 760);
        frame.getGlassPane().addMouseListener(new java.awt.event.MouseAdapter() {});
        frame.getGlassPane().addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {});
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> loading);
        showLogin();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void setPage(JPanel p) {
        frame.setContentPane(p);
        frame.revalidate();
        frame.repaint();
    }

    void fail(Exception e) {
        if (e instanceof ApiClient.ApiException a && a.status == 401 && user != null) {
            api.token("");
            user = null;
            showLogin();
        }
        String m = e.getMessage();
        JOptionPane.showMessageDialog(
                frame,
                m == null ? "Não foi possível concluir." : m,
                "LumIA",
                JOptionPane.WARNING_MESSAGE);
    }

    <T> void task(Callable<T> work, Consumer<T> done) {
        if (loading) return;
        loading = true;
        if (status != null) status.setText("Processando…");
        if (frame != null) {
            frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            frame.getGlassPane().setVisible(true);
        }
        new SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return work.call();
            }

            protected void done() {
                loading = false;
                if (frame != null) {
                    frame.setCursor(Cursor.getDefaultCursor());
                    frame.getGlassPane().setVisible(false);
                }
                if (status != null) status.setText("Pronto");
                try {
                    done.accept(get());
                } catch (Exception e) {
                    fail(e.getCause() instanceof Exception cause ? cause : e);
                }
            }
        }.execute();
    }

    /** Também utilizada pela verificação visual sem abrir uma janela. */
    public JPanel loginPanel() {
        JPanel p = page(), brand = form(), right = form();
        brand.setPreferredSize(new Dimension(470, 500));
        var logo = Desktop.class.getResource("/logo.jpeg");
        if (logo != null) {
            JLabel image =
                    new JLabel(
                            new ImageIcon(
                                    new ImageIcon(logo)
                                            .getImage()
                                            .getScaledInstance(440, 240, Image.SCALE_SMOOTH)));
            brand.add(image);
        }
        brand.add(heading("Entenda seu próximo passo."));
        brand.add(Box.createVerticalStrut(14));
        JLabel tagline = new JLabel("Notas, feedbacks e um plano para evoluir.");
        tagline.setForeground(BLUE);
        brand.add(tagline);
        brand.add(Box.createVerticalStrut(28));
        JLabel badge = new JLabel("ALUNO  ↔  PROFESSOR");
        badge.setForeground(GOLD);
        brand.add(badge);
        brand.add(Box.createVerticalStrut(16));
        brand.add(new JLabel("Inteligência que entende seu potencial."));
        right.setBorder(new EmptyBorder(65, 15, 20, 15));
        right.add(heading("Entrar no LumIA"));
        right.add(Box.createVerticalStrut(25));
        JTextField email = new JTextField();
        JPasswordField password = new JPasswordField();
        field(right, "E-mail", email);
        field(right, "Senha", password);
        JButton enter =
                button(
                        "Entrar",
                        () -> {
                            String mail = email.getText(),
                                    pass = new String(password.getPassword());
                            password.setText("");
                            task(
                                    () ->
                                            api.post(
                                                            "/login",
                                                            Json.map(
                                                                    "email",
                                                                    mail,
                                                                    "password",
                                                                    pass))
                                                    .getAsJsonObject(),
                                    result -> {
                                        user = result;
                                        api.token(result.get("token").getAsString());
                                        enterAccount();
                                    });
                        });
        right.add(enter);
        password.addActionListener(e -> enter.doClick());
        right.add(Box.createVerticalStrut(14));
        right.add(button("Criar conta de aluno", this::showRegister));
        right.add(Box.createVerticalStrut(22));
        right.add(new JLabel("Professor e ADM: contas criadas pelo responsável."));
        right.add(Box.createVerticalStrut(14));
        right.add(button("Redefinir senha com código", () -> showPassword(true)));
        p.add(brand, BorderLayout.WEST);
        p.add(right, BorderLayout.CENTER);
        p.add(new JLabel("Aplicativo Java • Conexão com o servidor LumIA"), BorderLayout.SOUTH);
        return p;
    }

    private void showLogin() {
        status = null;
        setPage(loginPanel());
    }

    private void showRegister() {
        JPanel p = page(), f = form();
        p.add(heading("Cadastro de aluno"), BorderLayout.NORTH);
        f.setBorder(new EmptyBorder(30, 180, 30, 180));
        JTextField name = new JTextField(), email = new JTextField();
        JPasswordField password = new JPasswordField(), confirm = new JPasswordField();
        field(f, "Nome", name);
        field(f, "E-mail", email);
        field(f, "Senha — 10 a 128 caracteres", password);
        field(f, "Confirme a senha", confirm);
        f.add(
                button(
                        "Cadastrar",
                        () -> {
                            String pass = new String(password.getPassword()),
                                    check = new String(confirm.getPassword());
                            if (!pass.equals(check)) {
                                fail(new Exception("As senhas não coincidem."));
                                return;
                            }
                            String n = name.getText(), mail = email.getText();
                            task(
                                    () ->
                                            api.post(
                                                    "/register",
                                                    Json.map(
                                                            "name",
                                                            n,
                                                            "email",
                                                            mail,
                                                            "password",
                                                            pass)),
                                    r -> {
                                        JOptionPane.showMessageDialog(
                                                frame,
                                                r.getAsJsonObject().get("message").getAsString());
                                        showLogin();
                                    });
                        }));
        f.add(Box.createVerticalStrut(12));
        f.add(button("Voltar ao login", this::showLogin));
        p.add(f);
        setPage(p);
    }

    private boolean teacher() {
        return user.get("role").getAsString().equals("PROFESSOR");
    }

    void safe(Runnable run) {
        try {
            run.run();
        } catch (Exception e) {
            fail(e);
        }
    }

    private void showDashboard() {
        JPanel p = page(), top = new JPanel(new BorderLayout()), bar = form();
        top.setOpaque(false);
        top.add(heading("Olá, " + user.get("name").getAsString()), BorderLayout.WEST);
        top.add(button("Sair", this::logout), BorderLayout.EAST);
        bar.add(top);
        bar.add(Box.createVerticalStrut(12));
        bar.add(
                new JLabel(
                        teacher()
                                ? "Professor • Acompanhe suas matérias e alunos"
                                : "Aluno • Acompanhe seu desempenho e participe"));
        courses = new JComboBox<>();
        lessons = new JComboBox<>();
        students = new JComboBox<>();
        courseInfo = new JLabel(" ");
        JPanel choices = new JPanel(new GridLayout(1, teacher() ? 3 : 2, 12, 0));
        choices.setOpaque(false);
        JPanel c = form();
        field(c, "Matéria / turma", courses);
        choices.add(c);
        JPanel l = form();
        field(l, "Aula / atividade", lessons);
        choices.add(l);
        if (teacher()) {
            JPanel a = form();
            field(a, "Aluno", students);
            choices.add(a);
        }
        bar.add(Box.createVerticalStrut(18));
        bar.add(choices);
        bar.add(courseInfo);
        p.add(bar, BorderLayout.NORTH);
        output = new JTextArea("Selecione uma matéria para consultar seus registros.");
        output.setEditable(false);
        output.setLineWrap(true);
        output.setWrapStyleWord(true);
        output.setFont(new Font("SansSerif", Font.PLAIN, 15));
        output.setMargin(new Insets(20, 20, 20, 20));
        p.add(new JScrollPane(output));
        JPanel actions = new JPanel(new GridLayout(0, 4, 8, 8));
        actions.setOpaque(false);
        actions.add(
                button(teacher() ? "Nova matéria" : "Matricular-se", () -> safe(this::addCourse)));
        if (teacher()) {
            actions.add(button("Nova aula", () -> safe(this::addLesson)));
            actions.add(button("Lançar nota", () -> safe(this::grade)));
            actions.add(button("Resumo da turma", () -> safe(this::overview)));
        }
        actions.add(button("Ver notas", () -> safe(() -> showRecords("/grades", "Notas"))));
        actions.add(button("Dar feedback", () -> safe(this::feedback)));
        actions.add(
                button("Ver feedbacks", () -> safe(() -> showRecords("/feedback", "Feedbacks"))));
        actions.add(button("Recomendações", () -> safe(this::recommend)));
        actions.add(button("Trocar senha", () -> showPassword(false)));
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(actions);
        status = new JLabel("Pronto");
        bottom.add(status, BorderLayout.SOUTH);
        p.add(bottom, BorderLayout.SOUTH);
        courses.addActionListener(
                e -> {
                    if (!loading) safe(this::loadCourse);
                });
        setPage(p);
        loadCourses();
    }

    private void loadCourses() {
        task(
                () -> api.get("/courses").getAsJsonArray(),
                rows -> {
                    loading = true;
                    courses.removeAllItems();
                    for (var row : rows) {
                        var r = row.getAsJsonObject();
                        courses.addItem(
                                new Item(
                                        r.get("id").getAsLong(),
                                        r.get("name").getAsString(),
                                        r.has("join_code")
                                                ? r.get("join_code").getAsString()
                                                : ""));
                    }
                    loading = false;
                    if (courses.getItemCount() > 0) loadCourse();
                    else
                        output.setText(
                                teacher()
                                        ? "Crie uma matéria e compartilhe o código com seus alunos."
                                        : "Peça o código da matéria ao professor e clique em"
                                                + " Matricular-se.");
                });
    }

    private void loadCourse() {
        if (courses.getSelectedItem() == null) return;
        Item course = selected(courses, "uma matéria");
        lessons.removeAllItems();
        students.removeAllItems();
        courseInfo.setText(
                teacher()
                        ? "Código de matrícula: " + course.code()
                        : "Seus registros nesta matéria");
        task(
                () ->
                        List.of(
                                api.get("/lessons?courseId=" + course.id()).getAsJsonArray(),
                                teacher()
                                        ? api.get("/students?courseId=" + course.id())
                                                .getAsJsonArray()
                                        : new JsonArray()),
                rows -> {
                    for (var row : rows.get(0)) {
                        var r = row.getAsJsonObject();
                        lessons.addItem(
                                new Item(
                                        r.get("id").getAsLong(), r.get("title").getAsString(), ""));
                    }
                    for (var row : rows.get(1)) {
                        var r = row.getAsJsonObject();
                        students.addItem(
                                new Item(r.get("id").getAsLong(), r.get("name").getAsString(), ""));
                    }
                    output.setText(
                            course.label()
                                    + "\n\n"
                                    + "Use os botões abaixo para consultar notas, registrar"
                                    + " feedbacks ou gerar recomendações.\n\n"
                                    + (teacher()
                                            ? "Lance uma nota por aluno e atividade. Novo envio"
                                                    + " substitui a nota anterior."
                                            : "Seu feedback ajuda a explicar o que funcionou e onde"
                                                    + " você precisa de apoio."));
                });
    }

    private void addCourse() {
        String text =
                JOptionPane.showInputDialog(
                        frame,
                        teacher()
                                ? "Nome da matéria e turma:"
                                : "Código fornecido pelo professor:");
        if (text == null) return;
        task(
                () ->
                        api.post(
                                teacher() ? "/courses" : "/join",
                                Json.map(teacher() ? "name" : "code", text)),
                r -> {
                    JOptionPane.showMessageDialog(
                            frame, r.getAsJsonObject().get("message").getAsString());
                    loadCourses();
                });
    }

    private void addLesson() {
        Item c = selected(courses, "uma matéria");
        String title = JOptionPane.showInputDialog(frame, "Título da aula / atividade:");
        if (title == null) return;
        task(
                () -> api.post("/lessons", Json.map("courseId", c.id(), "title", title)),
                r -> loadCourse());
    }

    private void grade() {
        Item lesson = selected(lessons, "uma aula"), student = selected(students, "um aluno");
        JPanel f = form();
        JTextField grade = new JTextField();
        JCheckBox delivered = new JCheckBox("Atividade entregue", true);
        field(f, "Nota de " + student.label() + " (0 a 10)", grade);
        f.add(delivered);
        if (JOptionPane.showConfirmDialog(frame, f, "Lançar nota", JOptionPane.OK_CANCEL_OPTION)
                != JOptionPane.OK_OPTION) return;
        String value = grade.getText();
        boolean wasDelivered = delivered.isSelected();
        task(
                () ->
                        api.post(
                                "/grades",
                                Json.map(
                                        "lessonId",
                                        lesson.id(),
                                        "studentId",
                                        student.id(),
                                        "grade",
                                        value,
                                        "delivered",
                                        wasDelivered)),
                r ->
                        output.setText(
                                "Nota salva para "
                                        + student.label()
                                        + ".\nClique em Ver notas para consultar."));
    }

    private void feedback() {
        Item lesson = selected(lessons, "uma aula");
        long student = teacher() ? selected(students, "um aluno").id() : user.get("id").getAsLong();
        JPanel f = form();
        JSpinner clarity = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1)),
                activity = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1)),
                difficulty = new JSpinner(new SpinnerNumberModel(3, 1, 5, 1));
        field(
                f,
                teacher()
                        ? "Clareza percebida da explicação (1 baixa, 5 alta)"
                        : "Clareza da explicação (1 baixa, 5 alta)",
                clarity);
        field(f, "Avaliação da atividade (1 ruim, 5 boa)", activity);
        field(f, "Dificuldade (1 baixa, 5 alta)", difficulty);
        JTextArea comment = new JTextArea(5, 38);
        comment.setLineWrap(true);
        comment.setWrapStyleWord(true);
        f.add(new JLabel("O que funcionou? O que faltou? O que precisa rever?"));
        f.add(new JScrollPane(comment));
        f.add(new JLabel("Visível ao aluno envolvido e ao professor. Máximo: 1.500 caracteres."));
        if (JOptionPane.showConfirmDialog(
                        frame, f, "Feedback • " + lesson.label(), JOptionPane.OK_CANCEL_OPTION)
                != JOptionPane.OK_OPTION) return;
        var body =
                Json.map(
                        "lessonId",
                        lesson.id(),
                        "studentId",
                        student,
                        "clarity",
                        clarity.getValue(),
                        "activity",
                        activity.getValue(),
                        "difficulty",
                        difficulty.getValue(),
                        "comment",
                        comment.getText());
        task(
                () -> api.post("/feedback", body),
                r -> output.setText(r.getAsJsonObject().get("message").getAsString()));
    }

    private void showRecords(String path, String title) {
        Item c = selected(courses, "uma matéria");
        task(
                () -> api.get(path + "?courseId=" + c.id()).getAsJsonArray(),
                rows -> {
                    if (rows.isEmpty()) {
                        output.setText(
                                "Nenhum registro de " + title.toLowerCase() + " nesta matéria.");
                        return;
                    }
                    StringBuilder text = new StringBuilder(title + " • " + c.label() + "\n\n");
                    for (var row : rows) {
                        for (var entry : row.getAsJsonObject().entrySet())
                            text.append(entry.getKey())
                                    .append(": ")
                                    .append(
                                            entry.getValue().isJsonNull()
                                                    ? "—"
                                                    : entry.getValue().getAsString())
                                    .append('\n');
                        text.append("\n────────────────────────\n\n");
                    }
                    output.setText(text.toString());
                    output.setCaretPosition(0);
                });
    }

    private void overview() {
        Item c = selected(courses, "uma matéria");
        task(
                () -> api.get("/overview?courseId=" + c.id()).getAsJsonObject(),
                r -> {
                    output.setText(r.get("text").getAsString());
                    output.setCaretPosition(0);
                });
    }

    private void recommend() {
        long student = teacher() ? selected(students, "um aluno").id() : user.get("id").getAsLong();
        String[] options = {"Regras do sistema", "Consultar IA", "Cancelar"};
        int choice =
                JOptionPane.showOptionDialog(
                        frame,
                        "A IA recebe médias, pendências e até 6 relatos por matéria (até 12 matérias).\n"
                            + "Os campos de nome e e-mail não são enviados. Evite dados pessoais"
                            + " nos comentários.\n"
                            + "Deseja consultar a IA configurada pelo responsável?",
                        "Recomendações",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);
        if (choice < 0 || choice == 2) return;
        task(
                () ->
                        api.post(
                                        "/recommendations",
                                        Json.map("studentId", student, "useAi", choice == 1))
                                .getAsJsonObject(),
                r -> {
                    output.setText(r.get("text").getAsString());
                    output.setCaretPosition(0);
                    if (r.has("resources") && !r.getAsJsonArray("resources").isEmpty()) {
                        JPanel links = new JPanel(new java.awt.GridLayout(0, 1, 5, 5));
                        links.add(
                                new JLabel(
                                        "Buscas por assunto no YouTube; vídeos não verificados."));
                        for (var item : r.getAsJsonArray("resources")) {
                            var resource = item.getAsJsonObject();
                            String url = resource.get("url").getAsString();
                            links.add(
                                    button(
                                            resource.get("title").getAsString(),
                                            () ->
                                                    safe(
                                                            () -> {
                                                                if (!url.startsWith(
                                                                        "https://www.youtube.com/results?search_query="))
                                                                    throw new IllegalArgumentException(
                                                                            "Link não permitido.");
                                                                try {
                                                                    java.awt.Desktop.getDesktop()
                                                                            .browse(
                                                                                    java.net.URI
                                                                                            .create(
                                                                                                    url));
                                                                } catch (java.io.IOException e) {
                                                                    throw new IllegalStateException(
                                                                            "Não foi possível abrir"
                                                                                + " o navegador."
                                                                                + " Copie o link do"
                                                                                + " plano.",
                                                                            e);
                                                                }
                                                            })));
                        }
                        JScrollPane scroll = new JScrollPane(links);
                        scroll.setPreferredSize(new java.awt.Dimension(650, 260));
                        JOptionPane.showMessageDialog(
                                frame, scroll, "Reforço por assunto", JOptionPane.PLAIN_MESSAGE);
                    }
                });
    }

    private void enterAccount() {
        if (user.get("mustChangePassword").getAsBoolean()) showPassword(false);
        else if (user.get("role").getAsString().equals("ADM")) showAdmin();
        else showDashboard();
    }

    void logout() {
        task(
                () -> api.post("/logout", Json.map()),
                r -> {
                    api.token("");
                    user = null;
                    showLogin();
                });
    }

    void showPassword(boolean reset) {
        JPanel p = page(), f = form();
        f.setBorder(new EmptyBorder(20, 160, 20, 160));
        p.add(heading(reset ? "Redefinir senha" : "Trocar senha"), BorderLayout.NORTH);
        JTextField email = new JTextField(), code = new JTextField();
        JPasswordField current = new JPasswordField(),
                next = new JPasswordField(),
                confirm = new JPasswordField();
        if (reset) {
            field(f, "E-mail", email);
            field(f, "Código fornecido pelo ADM/TI (válido por 10 minutos)", code);
        } else field(f, "Senha atual ou temporária", current);
        field(f, "Nova senha (10 a 128 caracteres)", next);
        field(f, "Confirme a nova senha", confirm);
        f.add(
                button(
                        "Salvar nova senha",
                        () -> {
                            String pass = new String(next.getPassword());
                            if (!pass.equals(new String(confirm.getPassword()))) {
                                fail(new Exception("As senhas não coincidem."));
                                return;
                            }
                            var data =
                                    reset
                                            ? Json.map(
                                                    "email",
                                                    email.getText(),
                                                    "code",
                                                    code.getText(),
                                                    "password",
                                                    pass)
                                            : Json.map(
                                                    "currentPassword",
                                                    new String(current.getPassword()),
                                                    "password",
                                                    pass);
                            task(
                                    () ->
                                            api.post(
                                                    reset ? "/reset-password" : "/change-password",
                                                    data),
                                    r -> {
                                        api.token("");
                                        user = null;
                                        showLogin();
                                        JOptionPane.showMessageDialog(
                                                frame, "Senha alterada. Entre novamente.");
                                    });
                        }));
        f.add(Box.createVerticalStrut(15));
        f.add(
                button(
                        reset ? "Voltar" : "Sair",
                        () -> {
                            if (reset) showLogin();
                            else logout();
                        }));
        p.add(f);
        setPage(p);
    }

    private void showAdmin() {
        AdminPanel panel = new AdminPanel(this);
        setPage(panel);
        panel.loadAdmin();
    }

    public JPanel adminPanel() {
        return new AdminPanel(this);
    }
}
