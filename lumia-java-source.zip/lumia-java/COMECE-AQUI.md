# LumIA v0.6 — comece aqui

1. `LOGINS_E_ACESSOS.txt`: contas de demonstração, senhas e permissões.
2. `LEIA-ME.md`: execução e configuração.
3. `docs/REVISAO-v0.6.md`: mudanças de segurança, IA e otimização.
4. `docs/INSTALAR-MARIADB.md`: preparação do banco real.

## Onde fica cada parte

Todos os arquivos Java ficam em `src/br/com/lumia`. Permanecem no mesmo pacote para facilitar a importação no Eclipse; as responsabilidades estão separadas por arquivo.

| Arquivo | Responsabilidade |
|---|---|
| Desktop.java | Inicia o aplicativo; login, cadastro, troca de senha e telas acadêmicas |
| AdminPanel.java | Tela de administração: contas, turmas, matrículas e histórico |
| Ui.java | Aparência e componentes visuais reutilizados pelas telas |
| ApiClient.java | Envia pedidos HTTP ao servidor e recebe JSON |
| Server.java | Recebe pedidos, valida sessão/permissões e chama a operação correspondente |
| AdminService.java | Regras administrativas e registro das operações |
| Database.java | Conexão JDBC, consultas parametrizadas, migração e transação de redefinição |
| Passwords.java | Gera e verifica hashes das senhas |
| Recommendations.java | Consulta registros, calcula médias e monta recomendações por regras |
| GeminiClient.java | Consulta Gemini com limite de concorrência, configuração local e fallback |
| AiPolicy.java | Contexto mínimo, catálogo de ações, esquema JSON e validação da saída |
| Json.java | Conversão JSON e leitura de campos das requisições |
| resources/schema.sql | Criação das tabelas, PKs, FKs e restrições |

## Ordem de estudo

1. `docs/estudo/01-telas.md`
2. `docs/estudo/02-comunicacao.md`
3. `docs/estudo/03-servidor-seguranca.md`
4. `docs/estudo/04-banco.md`
5. `docs/estudo/05-administracao.md`
6. `docs/estudo/06-recomendacoes.md`

Acompanhe primeiro um login completo. Depois siga um lançamento de nota. Não é necessário ler todas as classes de uma vez.

## O que foi simplificado

- Código formatado com indentação e instruções em linhas separadas.
- Painel ADM retirado de Desktop e colocado em AdminPanel.
- Componentes visuais comuns reunidos em Ui.
- Operações do servidor divididas em métodos, como listCourses, saveGrade e saveFeedback.
- Recomendações divididas em consulta, cálculo/plano e chamada externa; GeminiClient concentra a chamada à IA.
- Cálculo das médias com laços explícitos; remoção de conversão não verificada da lista de feedbacks.
- Botão de saída reaproveita a mesma rotina.

## O que foi otimizado

- GeminiClient reaproveita um HttpClient, em vez de construir um novo a cada consulta.
- Database lê os nomes e a quantidade de colunas uma vez por resultado, em vez de repetir isso em cada linha.
- Compilação limpa somente a pasta gerada `build`, evitando classes antigas nos JARs.

Não foi medido ganho percentual de velocidade. As principais melhorias são de organização e manutenção; as consultas de notas e feedbacks ainda são feitas por matéria.

## Verificação e limites

Compilação Java 17 e regressão com as suítes acadêmica e administrativa. Os testes usam bancos H2 temporários e não chamam o Gemini real. A divisão dos arquivos não exige alteração do esquema da v0.2. MariaDB real, Gemini e interação completa das janelas no Windows continuam pendentes de validação no seu ambiente.

O projeto permanece um protótipo didático. Ainda há métodos longos nas telas e uso de Map para representar registros; uma futura evolução pode introduzir classes de domínio e separar controladores, depois que você dominar esta versão. As sessões são tokens aleatórios em memória, **não JWT**. A estrutura possui separação de responsabilidades, mas **não implementa um MVC completo**.

## Atualização v0.4 — reforço

A recomendação usa os assuntos das menores notas entregues, sem classificar proficiência. Os botões abrem buscas no YouTube, não vídeos verificados. Leia `docs/estudo/06-recomendacoes.md`.
