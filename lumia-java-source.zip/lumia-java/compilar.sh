#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf build
mkdir -p build/client/br/com/lumia build/server/br/com/lumia
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 --release 17 -cp lib/gson-2.11.0.jar -d build src/br/com/lumia/*.java
for name in Desktop AdminPanel Ui ApiClient Json; do cp build/br/com/lumia/"$name"*.class build/client/br/com/lumia/; done
for name in Server Database Passwords Recommendations GeminiClient AiPolicy AdminService Json; do cp build/br/com/lumia/"$name"*.class build/server/br/com/lumia/; done
cp resources/logo.jpeg build/client/
cp resources/schema.sql build/server/
java -m jdk.jartool/sun.tools.jar.Main --create --file lumia-desktop.jar --manifest desktop-manifest.mf -C build/client .
java -m jdk.jartool/sun.tools.jar.Main --create --file lumia-servidor.jar --manifest server-manifest.mf -C build/server .
