"""Teste de integração: execute contra um servidor --demo em banco descartável."""
import json, urllib.request, urllib.error, uuid
BASE='http://127.0.0.1:8080'
checks=0

def request(path, data=None, token=None, expected=200):
    global checks
    headers={'Content-Type':'application/json'}
    if token: headers['Authorization']='Bearer '+token
    req=urllib.request.Request(BASE+path, data=None if data is None else json.dumps(data).encode(),headers=headers)
    try:
        with urllib.request.urlopen(req,timeout=55) as r: status=r.status;result=json.load(r)
    except urllib.error.HTTPError as e: status=e.code;result=json.load(e)
    assert status==expected,(path,status,expected,result)
    checks+=1
    return result

def login(email,password):return request('/login',dict(email=email,password=password))['token']

request('/health')
request('/courses',expected=401)
t=login('professor@lumia.local','Professor123!')
a=login('aluno@lumia.local','Aluno12345!')
request('/login',dict(email='aluno@lumia.local',password='WrongPass123!'),expected=401)
email='teste-'+uuid.uuid4().hex+'@lumia.local'
request('/register',dict(name='Aluno Teste',email=email,password='Teste123456!',role='PROFESSOR'))
request('/register',dict(name='Duplicado',email=email,password='Teste123456!'),expected=409)
admin=login('admin@lumia.local','Admin12345!')
uid=next(u['id'] for u in request('/admin/users',token=admin) if u['email']==email)
request('/admin/user-status',dict(id=uid,status='ATIVO'),admin)
b=login(email,'Teste123456!')
request('/courses',dict(name='Tentativa de elevação'),b,403)
courses=request('/courses',token=t);c=courses[0]['id'];code=courses[0]['join_code']
assert 'join_code' not in request('/courses',token=a)[0]
request('/grades?courseId='+str(c),token=b,expected=403)
request('/join',dict(code=code),b)
request('/join',dict(code=code),b,409)
people=request('/students?courseId='+str(c),token=t)
bid=next(p['id'] for p in people if p['email']==email)
aid=next(p['id'] for p in people if p['email']=='aluno@lumia.local')
request('/students?courseId='+str(c),token=a,expected=403)
l=request('/lessons?courseId='+str(c),token=t)[0]['id']
request('/grades',dict(lessonId=l,studentId=bid,grade=10,delivered=True),b,403)
request('/grades',dict(lessonId=l,studentId=bid,grade=11,delivered=True),t,400)
request('/grades',dict(lessonId=l,studentId=999999,grade=6,delivered=True),t,400)
request('/grades',dict(lessonId=l,studentId=bid,grade='5,5',delivered=True),t)
request('/grades',dict(lessonId=l,studentId=bid,grade='7,5',delivered=True),t)
assert len(request('/grades?courseId='+str(c),token=b))==1
assert float(request('/grades?courseId='+str(c),token=b)[0]['nota'])==7.5
assert all(r['aluno']=='Aluno Teste' for r in request('/grades?courseId='+str(c),token=b))
# O aluno tenta forjar outro studentId; o servidor usa o autor autenticado.
fb=dict(lessonId=l,studentId=aid,clarity=2,activity=3,difficulty=4,comment='Dúvida na explicação')
request('/feedback',fb,b)
fb['comment']='Ainda preciso de exemplos';request('/feedback',fb,b)
feedbacks=request('/feedback?courseId='+str(c),token=b)
assert len(feedbacks)==1 and feedbacks[0]['aluno']=='Aluno Teste'
assert feedbacks[0]['comentario']=='Ainda preciso de exemplos'
assert all(r['aluno']=='Aluno Demo' for r in request('/feedback?courseId='+str(c),token=a))
report=request('/recommendations',dict(studentId=aid,useAi=False),b)
assert '7,5' in report['text'] and '4,5' not in report['text']
assert 'relato de dificuldade alta' in report['text']
assert report['resources'][0]['grade']==7.5
assert report['resources'][0]['type']=='YOUTUBE_SEARCH'
assert report['resources'][0]['url'].startswith('https://www.youtube.com/results?search_query=')
assert 'não determina proficiência' in report['text']
request('/recommendations',dict(studentId=999999,useAi=False),t,403)
report=request('/recommendations',dict(useAi=True),b)
assert report['source']=='REGRAS' and 'não configurada' in report['text']
request('/recommendations',dict(useAi=True),b,429)
overview=request('/overview?courseId='+str(c),token=t)['text']
assert 'Aluno Teste' in overview and 'Abaixo de 6: 1' in overview
request('/overview?courseId='+str(c),token=b,expected=403)
request('/courses',dict(name='Português Teste'),t)
new=next(x for x in request('/courses',token=t) if x['name']=='Português Teste')
request('/join',dict(code=new['join_code']),b)
assert 'Sem notas registradas' in request('/recommendations',dict(useAi=False),b)['text']
request('/lessons',dict(courseId=new['id'],title='Interpretação de texto'),t)
# Menores notas ordenam assuntos; não entregues são pendências, não reforço por nota.
lessons=[]
for title,grade,delivered in [('Frações & proporções',3,True),('Equações',5,True),('Pendente',0,False)]:
    request('/lessons',dict(courseId=new['id'],title=title),t)
    lesson=next(x for x in request('/lessons?courseId='+str(new['id']),token=t) if x['title']==title)
    request('/grades',dict(lessonId=lesson['id'],studentId=bid,grade=grade,delivered=delivered),t)
r=request('/recommendations',dict(useAi=False),b)
items=[x for x in r['resources'] if x['title'].startswith('Português Teste')]
assert [x['grade'] for x in items]==[3,5]
from urllib.parse import urlparse,parse_qs
assert 'Frações & proporções' in parse_qs(urlparse(items[0]['url']).query)['search_query'][0]
assert 'Média simples: 4,0 (2 registros)' in r['text']
request('/logout',{},b)
request('/courses',token=b,expected=401)
print(f'OK: {checks} requisições verificadas; cadastro, permissões, notas, feedbacks, médias, fallback e logout.')
