import json,urllib.request,urllib.error
BASE='http://127.0.0.1:8080';checks=0

def req(path,data=None,token=None,status=200):
 global checks
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 request=urllib.request.Request(BASE+path,data=None if data is None else json.dumps(data).encode(),headers=headers)
 try:
  with urllib.request.urlopen(request,timeout=50) as r:code=r.status;value=json.load(r)
 except urllib.error.HTTPError as e:code=e.code;value=json.load(e)
 assert code==status,(path,code,status,value)
 checks+=1;return value

def login(email,password,status=200):return req('/login',dict(email=email,password=password),status=status)
def users(token):return req('/admin/users',token=token)
a=login('admin@lumia.local','Admin12345!');adm=a['token']
t=login('professor@lumia.local','Professor123!')['token'];s=login('aluno@lumia.local','Aluno12345!')['token']
req('/admin/users',status=401)
for token in [t,s]:
 for path in ['/admin/users','/admin/courses','/admin/enrollments','/admin/audit']:req(path,token=token,status=403)
 req('/admin/users',dict(name='Invasor',email='invasor@local.com',role='ADM'),token,status=403)
assert all('password_hash' not in row for row in users(adm))
req('/register',dict(name='Novo Aluno',email='novo@lumia.local',password='AlunoNovo123!',role='ADM',status='ATIVO'))
login('novo@lumia.local','AlunoNovo123!',403)
u=next(u for u in users(adm) if u['email']=='novo@lumia.local');assert u['role']=='ALUNO' and u['status']=='PENDENTE'
req('/admin/user-status',dict(id=u['id'],status='ATIVO'),adm)
new=login('novo@lumia.local','AlunoNovo123!')['token']
req('/admin/user-status',dict(id=u['id'],status='INATIVO'),adm)
req('/courses',token=new,status=401);login('novo@lumia.local','AlunoNovo123!',403)
req('/admin/user-status',dict(id=u['id'],status='ATIVO'),adm)
req('/admin/user-status',dict(id=a['id'],status='INATIVO'),adm,status=400)
created=req('/admin/users',dict(name='Professor Novo',email='prof2@lumia.local',role='PROFESSOR'),adm)
p=login('prof2@lumia.local',created['temporaryPassword']);assert p['mustChangePassword']
req('/courses',token=p['token'],status=403)
req('/change-password',dict(currentPassword='errada12345',password='NovaSenha123!'),p['token'],400)
req('/change-password',dict(currentPassword=created['temporaryPassword'],password='NovaSenha123!'),p['token'])
req('/courses',token=p['token'],status=401)
p=login('prof2@lumia.local','NovaSenha123!');assert not p['mustChangePassword']
req('/admin/courses',dict(name='História • Turma B',teacherId=created['id']),adm)
c=next(c for c in req('/admin/courses',token=adm) if c['teacher_id']==created['id'])
req('/admin/enrollment-add',dict(courseId=c['id'],studentId=u['id']),adm)
req('/admin/enrollment-add',dict(courseId=c['id'],studentId=created['id']),adm,400)
new=login('novo@lumia.local','AlunoNovo123!')['token'];assert len(req('/courses',token=new))==1
req('/admin/course-edit',dict(id=c['id'],name='História atualizada',teacherId=created['id']),adm)
req('/admin/enrollment-remove',dict(courseId=c['id'],studentId=u['id']),adm);assert req('/courses',token=new)==[]
reset=req('/admin/password-reset',dict(id=u['id']),adm)['resetCode']
req('/courses',token=new,status=401)
req('/reset-password',dict(email='novo@lumia.local',code='incorreto',password='SenhaRedefinida123!'),status=400)
req('/reset-password',dict(email='novo@lumia.local',code=reset,password='SenhaRedefinida123!'))
req('/reset-password',dict(email='novo@lumia.local',code=reset,password='OutraSenha123!'),status=400)
new=login('novo@lumia.local','SenhaRedefinida123!')['token']
req('/admin/user-edit',dict(id=u['id'],name='Nome Editado',email='editado@lumia.local'),adm)
req('/courses',token=new,status=401);login('editado@lumia.local','SenhaRedefinida123!')
other=req('/admin/users',dict(name='Outro ADM',email='adm2@lumia.local',role='ADM'),adm)
otherlogin=login('adm2@lumia.local',other['temporaryPassword'])
req('/admin/users',token=otherlogin['token'],status=403)
req('/change-password',dict(currentPassword=other['temporaryPassword'],password='Administrador2!'),otherlogin['token'])
otherlogin=login('adm2@lumia.local','Administrador2!')
req('/admin/user-status',dict(id=a['id'],status='INATIVO'),otherlogin['token'])
req('/admin/users',token=adm,status=401)
req('/admin/user-status',dict(id=other['id'],status='INATIVO'),otherlogin['token'],400)
audit=req('/admin/audit',token=otherlogin['token']);assert len(audit)>10
assert reset not in json.dumps(audit) and created['temporaryPassword'] not in json.dumps(audit)
print('OK:',checks,'requisições ADM/TI, permissões, senhas, matrículas e auditoria.')
