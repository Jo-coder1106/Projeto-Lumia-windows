"""Executa cada conjunto em um banco temporário, sem alterar os dados do usuário."""
import os
import pathlib
import subprocess
import tempfile
import sys

root = pathlib.Path(__file__).resolve().parents[1]
for suite in ('integration.py', 'admin_integration.py', 'security_integration.py'):
    with tempfile.TemporaryDirectory() as directory:
        environment = os.environ.copy()
        environment.pop('GEMINI_API_KEY', None)
        environment['GEMINI_MODEL'] = 'OFFLINE TEST - NO NETWORK'
        environment['LUMIA_PORT'] = '8080'
        server = subprocess.Popen(
            ['java', '-jar', str(root / 'lumia-servidor.jar'), '--demo'],
            cwd=directory, env=environment, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True)
        try:
            first_line = server.stdout.readline()
            if 'LumIA em' not in first_line:
                raise RuntimeError('Servidor de testes não iniciou: ' + first_line)
            subprocess.run([sys.executable, str(root / 'test' / suite)], check=True)
        finally:
            server.terminate()
            server.wait(timeout=15)

subprocess.run(["java", "--class-path", os.pathsep.join([str(root / "lumia-servidor.jar"), str(root / "lib" / "*")]), str(root / "test" / "DatabaseIntegration.java")], check=True)

# Compila o teste no mesmo pacote para exercitar o validador usado em produção.
with tempfile.TemporaryDirectory() as classes:
    classpath = os.pathsep.join([str(root / "lumia-servidor.jar"), str(root / "lib" / "*")])
    subprocess.run(["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-encoding", "UTF-8", "-cp", classpath, "-d", classes, str(root / "test/br/com/lumia/AiPolicyTest.java")], check=True)
    subprocess.run(["java", "-cp", os.pathsep.join([classes, classpath]), "br.com.lumia.AiPolicyTest"], check=True)
