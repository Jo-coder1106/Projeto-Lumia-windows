package br.com.lumia;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class Preview {
 static void layout(Container c){c.doLayout();for(Component child:c.getComponents())if(child instanceof Container nested)layout(nested);}
 public static void main(String[] args)throws Exception{
  SwingUtilities.invokeAndWait(()->{
   try{
    Desktop desktop=new Desktop("http://127.0.0.1:8080"); JPanel p=args.length>1?desktop.adminPanel():desktop.loginPanel(); if(args.length>1){var field=AdminPanel.class.getDeclaredField("adminData");field.setAccessible(true);field.set(p,java.util.List.of(com.google.gson.JsonParser.parseString("[{\"id\":3,\"name\":\"Administrador Demo\",\"email\":\"admin@lumia.local\",\"role\":\"ADM\",\"status\":\"ATIVO\"},{\"id\":2,\"name\":\"Aluno Demo\",\"email\":\"aluno@lumia.local\",\"role\":\"ALUNO\",\"status\":\"ATIVO\"},{\"id\":1,\"name\":\"Professor Demo\",\"email\":\"professor@lumia.local\",\"role\":\"PROFESSOR\",\"status\":\"ATIVO\"}]").getAsJsonArray(),new com.google.gson.JsonArray(),new com.google.gson.JsonArray(),new com.google.gson.JsonArray()));var fill=AdminPanel.class.getDeclaredMethod("fillAdmin");fill.setAccessible(true);fill.invoke(p);} p.setSize(1100,760);layout(p);
    BufferedImage image=new BufferedImage(1100,760,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);p.printAll(g);g.dispose();ImageIO.write(image,"png",new File(args[0]));
   }catch(Exception e){throw new RuntimeException(e);}
  });
 }
}
