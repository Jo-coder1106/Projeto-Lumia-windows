import br.com.lumia.Database;
import java.nio.file.Files;
import java.sql.SQLException;

/** Teste em banco descartável, sem alterar dados do usuário. */
class DatabaseIntegration {
    static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        var path = Files.createTempDirectory("lumia-db-test-");
        String url = "jdbc:h2:" + path.resolve("db") + ";MODE=MariaDB;DATABASE_TO_LOWER=TRUE";
        Database db = new Database(url, "sa", "");
        try {
            db.ping();
            db.initialize();
            long id = db.transaction(tx -> {
                long key = tx.insert("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                        "Teste", "teste@example.test", "hash-ficticio", "ALUNO");
                tx.update("UPDATE users SET name=? WHERE id=?", "Confirmado", key);
                check(tx.query("SELECT id FROM users WHERE id=?", key).size() == 1, "consulta interna");
                return key;
            });
            check(db.query("SELECT name FROM users WHERE id=?", id).get(0).get("name").equals("Confirmado"), "commit");
            try {
                db.transaction(tx -> {
                    tx.update("UPDATE users SET name=? WHERE id=?", "Desfazer", id);
                    tx.insert("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                            "Duplicado", "teste@example.test", "hash-ficticio", "ALUNO");
                    return null;
                });
                throw new AssertionError("unicidade");
            } catch (SQLException expected) { }
            check(db.query("SELECT name FROM users WHERE id=?", id).get(0).get("name").equals("Confirmado"), "rollback SQL");
            try {
                db.transaction(tx -> {
                    tx.update("UPDATE users SET name=? WHERE id=?", "Desfazer", id);
                    throw new IllegalStateException("simulação");
                });
            } catch (IllegalStateException expected) { }
            check(db.query("SELECT name FROM users WHERE id=?", id).get(0).get("name").equals("Confirmado"), "rollback aplicação");
            db.update("INSERT INTO password_resets VALUES(?,?,?)", id, "token-teste", System.currentTimeMillis()+60000);
            db.update("UPDATE users SET status='INATIVO' WHERE id=?", id);
            check(!db.redeemReset(id, "token-teste", "novo-hash", System.currentTimeMillis()), "reset inativo");
            check(db.query("SELECT user_id FROM password_resets WHERE user_id=?", id).size()==1, "token restaurado");
            db.update("UPDATE users SET status='ATIVO' WHERE id=?", id);
            check(db.redeemReset(id, "token-teste", "novo-hash", System.currentTimeMillis()), "reset ativo");
            check(!db.redeemReset(id, "token-teste", "outro-hash", System.currentTimeMillis()), "token único");
            Database reopened = new Database(url, "sa", "");
            reopened.initialize();
            check(reopened.query("SELECT password_hash FROM users WHERE id=?", id).get(0).get("password_hash").equals("novo-hash"), "persistência");
            System.out.println("OK: transações, rollback, token de uso único e persistência após reinicialização (H2).");
        } finally {
            try (var files = Files.walk(path)) {
                for (var file : files.sorted(java.util.Comparator.reverseOrder()).toList()) Files.delete(file);
            }
        }
    }
}
