﻿# LumIA: inicia o servidor Java com MariaDB. Execute no PowerShell.
# Senhas digitadas ficam ocultas; o Java as recebe por variáveis de ambiente do processo.
# Valores preexistentes são preservados e restaurados ao terminar.
$ErrorActionPreference = 'Stop'
$names = @('LUMIA_DB_URL','LUMIA_DB_USER','LUMIA_DB_PASSWORD',
           'LUMIA_ADMIN_EMAIL','LUMIA_ADMIN_NAME','LUMIA_ADMIN_PASSWORD')
$previous = @{}
foreach ($name in $names) { $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }

function Read-Plain([string]$Prompt) {
    $secure = Read-Host $Prompt -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        $secure.Dispose()
    }
}

Push-Location $PSScriptRoot
try {
    if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
        throw 'Java não encontrado. Instale Java 17 ou superior e abra o terminal novamente.'
    }
    if (-not (Test-Path '.\lumia-servidor.jar')) { throw 'lumia-servidor.jar não encontrado. Extraia o ZIP completo.' }
    if (-not $env:LUMIA_DB_URL) { $env:LUMIA_DB_URL = 'jdbc:mariadb://localhost:3306/lumia' }
    if (-not $env:LUMIA_DB_USER) { $env:LUMIA_DB_USER = 'lumia' }
    if (-not $env:LUMIA_DB_PASSWORD) {
        $env:LUMIA_DB_PASSWORD = Read-Plain "Senha do usuário '$($env:LUMIA_DB_USER)' no MariaDB"
    }
    # O servidor só cria esta conta se ainda não existir nenhum ADM.
    if (-not $env:LUMIA_ADMIN_EMAIL) {
        $email = Read-Host 'E-mail do primeiro administrador (Enter se já existe ADM)'
        if ($email) { $env:LUMIA_ADMIN_EMAIL = $email }
    }
    if ($env:LUMIA_ADMIN_EMAIL) {
        if (-not $env:LUMIA_ADMIN_NAME) {
            $name = Read-Host 'Nome do administrador (Enter para Administrador)'
            if ($name) { $env:LUMIA_ADMIN_NAME = $name }
        }
        if (-not $env:LUMIA_ADMIN_PASSWORD) {
            $env:LUMIA_ADMIN_PASSWORD = Read-Plain 'Senha do administrador (10+ caracteres)'
        }
    }
    & java -jar lumia-servidor.jar
    if ($LASTEXITCODE -ne 0) { throw "O servidor encerrou com código $LASTEXITCODE. Confira a mensagem acima." }
}
finally {
    foreach ($name in $names) {
        [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process')
    }
    Pop-Location
}
