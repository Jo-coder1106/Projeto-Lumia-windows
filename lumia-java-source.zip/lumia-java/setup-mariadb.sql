-- LumIA — preparação do MariaDB (execute UMA vez, com uma conta administrativa).
--
--   No cliente MariaDB: SOURCE C:/caminho/lumia-java/setup-mariadb.sql;
--   (ou cole o conteúdo no HeidiSQL / DBeaver / outro cliente SQL conectado ao MariaDB)
--
-- ANTES DE EXECUTAR: troque SUBSTITUA_POR_SENHA_FORTE por uma senha sua.
-- As tabelas NÃO são criadas aqui: o servidor as cria sozinho no primeiro início
-- (resources/schema.sql). Este script só cria o banco vazio e o usuário da aplicação.

CREATE DATABASE IF NOT EXISTS lumia
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'lumia'@'localhost' IDENTIFIED BY 'SUBSTITUA_POR_SENHA_FORTE';

-- Sem root na aplicação: apenas o necessário (CREATE/ALTER/REFERENCES servem à criação
-- e à migração das tabelas na inicialização).
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, REFERENCES ON lumia.* TO 'lumia'@'localhost';
-- GRANT e CREATE USER já aplicam as permissões; não é necessário FLUSH PRIVILEGES.

-- Conferência (opcional):
-- SHOW GRANTS FOR 'lumia'@'localhost';

-- Se o usuário já existir, CREATE USER IF NOT EXISTS NÃO altera sua senha.
-- Nesse caso, use a senha existente ao iniciar o servidor.
