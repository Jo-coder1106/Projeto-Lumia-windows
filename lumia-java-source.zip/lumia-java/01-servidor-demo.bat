@echo off
cd /d "%~dp0"
java -jar lumia-servidor.jar --demo
pause
