@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0servidor-mariadb.ps1"
pause
